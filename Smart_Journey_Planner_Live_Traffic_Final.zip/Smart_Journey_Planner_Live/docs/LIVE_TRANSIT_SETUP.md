# Live Transit Setup Guide

## What this release supports

This release adds a standards-based public-transport integration alongside the preserved C route engine, Flask API, SQLite database and dashboard:

- GTFS Schedule ZIP import: stops, routes, trips, stop times and service calendars.
- Multi-operator timetable imports: use **Add to existing feeds** and a unique prefix for every operator. Use the same prefix for that operator's realtime feed.
- Timetable journey search across bus, metro, rail, tram and other GTFS route types, including up to three changes. A five-minute minimum connection time is used when changing trips.
- GTFS `transfers.txt` import and manually defined bidirectional walking transfers between operator stops, so separately imported bus and metro feeds can be connected.
- GTFS-Realtime vehicle positions on the map, trip updates/delays/cancellations and service alerts.
- Feed freshness labels: vehicle/trip feeds older than 90 seconds are marked stale; alert feeds older than 10 minutes are marked stale.

The app does not contain a universal transit API key or a preloaded real-time feed. Real-time information appears only after the relevant transport operator supplies an authorized HTTPS GTFS-Realtime endpoint. A timetable is scheduled information, not live GPS.

## 1. Import a static GTFS schedule

1. Obtain a GTFS Schedule ZIP from the transit agency or an official open-data portal.
2. Start the website with `run_windows.bat`.
3. In **Live transit centre**, choose the ZIP file.
4. Set an operator prefix, for example `delhi` or `dmrc`.
5. For the first operator, leave **Add to existing feeds** unchecked. For every additional operator, check it and use a different prefix.
6. Click **Import timetable**.
7. The stop selectors become available after import.

The ZIP must include `stops.txt`, `routes.txt`, `trips.txt`, `stop_times.txt`, and at least one of `calendar.txt` or `calendar_dates.txt`.

The prefix avoids collisions when two agencies both use IDs such as `1`, `A1` or `trip_001`. Example: `delhi:123`. When importing a second operator, tick **Add to existing feeds** and use a different prefix. You can then add a walking transfer between nearby stops from the two feeds in the dashboard, or rely on imported GTFS `transfers.txt` records.

## 2. Configure a live GTFS-Realtime feed

1. Obtain the official Vehicle Positions, Trip Updates and/or Service Alerts feed URL from the operator. Some agencies require registration, an API key or a signed data agreement.
2. Open `config/transit_feeds.json` in Notepad.
3. Add one provider object per operator. Example:

```json
{
  "name": "Example City Bus",
  "id_prefix": "examplebus",
  "vehicle_url_env": "EXAMPLEBUS_VEHICLE_URL",
  "trip_update_url_env": "EXAMPLEBUS_TRIP_UPDATES_URL",
  "alert_url_env": "EXAMPLEBUS_ALERTS_URL"
}
```

4. Add that object inside the `feeds` array, separated by commas from other objects.
5. Copy `.env.example` to a new file named `.env` in the project root.
6. Add the actual feed URL(s) to `.env`, using the environment-variable names above. Keep API keys inside `.env`; never upload `.env` to GitHub or share it publicly.
7. Set `id_prefix` to exactly the same prefix used when importing that operator's static schedule.
8. Restart the app and press **Refresh feeds**.

Only HTTPS feed URLs are accepted. The adapter expects GTFS-Realtime Protocol Buffer feeds. Proprietary JSON, SIRI, vendor-specific APIs and railway enquiry APIs are not automatically interchangeable with GTFS-Realtime; they need their own adapter.

## 3. Delhi Open Transit Data example

Delhi's Open Transit Data portal publishes static Delhi bus GTFS data. Its documentation says the static bus timetable includes stops, routes, trips, stop times and calendar data, but warns that the times are rough estimates based on assumed constant speed. The portal documents the realtime vehicle-position endpoint as:

`https://otd.delhi.gov.in/api/realtime/VehiclePositions.pb?key=YOUR_PRIVATE_KEY`

Real-time access is for authorized users. Apply for access through the portal before expecting live bus locations. The documented endpoint above is a vehicle-position feed; do not assume Delhi trip-update or alert endpoints exist unless the portal supplies them to your account.

Suggested setup:

- Request the static data from [Delhi Open Transit Data – Static Data](https://otd.delhi.gov.in/data/static/). Complete the portal's stated purpose/terms process, then import its ZIP with prefix `delhi`.
- Request real-time API access from [Delhi Open Transit Data – Real Time Data](https://otd.delhi.gov.in/data/realtime/).
- Once authorized, add the complete vehicle-position URL to `.env` as `DELHI_VEHICLE_FEED_URL`.
- The included `config/transit_feeds.json` already has the Delhi provider entry and `id_prefix: delhi`.

Delhi Metro static data is also available from [Delhi Open Transit Data – DMRC Static Data](https://otd.delhi.gov.in/data/staticDMRC/). Import it with prefix `dmrc` and tick **Add to existing feeds** after importing the bus schedule. The portal lists 262 stations and 36 metro routes and says its schedule times are approximate; it lists the data last updated in August 2023. This release does not claim live DMRC train positions. If an official DMRC realtime feed is available to you, add it as a separate provider with `id_prefix: dmrc`. Add a walking transfer between a bus stop and metro station if their IDs are different.

## 4. Understanding the status labels

- **NOT_CONFIGURED**: no URL has been entered for that feed.
- **LIVE**: the feed endpoint was retrieved and parsed successfully. Check its freshness label too.
- **FRESH**: the feed header timestamp is within the GTFS-Realtime recommended freshness window.
- **FEED STALE**: the feed is older than the freshness threshold. Do not rely on it as current.
- **ERROR**: the endpoint could not be fetched or parsed. Check URL, authorization, network access and provider format.
- **AGE UNKNOWN**: the feed did not provide a usable header timestamp.

## 5. Important limitations

- Live vehicle markers require a Vehicle Positions feed with coordinates.
- Predicted arrival/delay display requires Trip Updates and a matching static schedule/trip ID.
- Alerts require a Service Alerts feed.
- Feed IDs must match static schedule IDs; configure the same `id_prefix` on the static import and realtime provider.
- The journey planner currently computes scheduled earliest-arrival journeys from the imported GTFS service calendar. It uses GTFS transfer records and manual walking-transfer links to connect operators. Realtime trip delays/cancellations are displayed as overlays; the current itinerary search does not yet re-run the full connection search using every realtime delay.
- GTFS feeds can cover buses, metro, rail, tram and ferry, but only if the agency publishes the corresponding route and schedule data.
- No confirmed Uttarakhand/Dehradun live GTFS-Realtime provider is bundled. Do not present the sample road graph's estimated journey data as live public transport.
- Map tiles are loaded from OpenStreetMap's standard tile service and require internet access. Follow its attribution and usage policy; the app does not download tiles for offline use.
