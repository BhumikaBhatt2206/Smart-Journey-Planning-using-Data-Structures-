# Final Project Report — Smart Journey Planner

## 1. Project overview

Smart Journey Planner is a data-structures-based journey planning application. It models cities as vertices and direct travel links as weighted undirected edges. Users can calculate a route based on distance, estimated time or estimated fare, explore a route with the fewest graph edges, and inspect reachable cities.

## 2. Problem statement

A traveller may have multiple possible paths between two locations. Selecting a route manually can be inefficient. The project demonstrates how graph representations and graph algorithms can compare routes using different edge weights and how a web interface can make the results accessible.

## 3. Objectives

- Represent a travel network using a graph.
- Find optimal weighted paths using Dijkstra's algorithm.
- Demonstrate BFS and DFS traversal.
- Use a binary min-heap to efficiently select the next minimum-distance vertex.
- Store editable city and connection data persistently in SQLite.
- Expose calculations through a Flask API and browser dashboard.
- Preserve and extend the team's original C implementation.

## 4. Architecture

```text
Browser UI (HTML, CSS, JavaScript, SVG)
                  |
              HTTP / JSON
                  |
           Python Flask app
             /          \
            /            \
     SQLite database    C engine bridge
     cities/routes/          |
       history               | temporary graph export
                             v
                       C executable
                   Graph + min-heap + hash
                  Dijkstra / BFS / DFS
```

The browser does not perform route calculations. Flask reads the current graph from SQLite, exports it to the input format understood by the C CLI, invokes the C executable, parses its JSON response and returns the result to the browser.

## 5. Data structures and algorithms

- **Graph:** cities are vertices; road links are undirected weighted edges.
- **Adjacency list:** stores the neighbours of each city without allocating a full matrix.
- **Binary min-heap:** supports efficient extraction of the next city with the smallest tentative Dijkstra distance.
- **Hash table:** supports city-name lookup.
- **Stack/path reconstruction:** reconstructs the selected route from predecessor information.
- **Dijkstra:** computes a minimum-weight route for the chosen metric. All weights must be non-negative.
- **BFS:** finds a route using the fewest edges in an unweighted sense.
- **DFS:** explores all cities reachable from a selected start city.

## 6. Technology choices

| Technology | Role | Reason |
|---|---|---|
| C11 | Algorithm engine | Preserves the original academic implementation and demonstrates low-level DSA |
| Python | Backend integration | Simple process orchestration and API implementation |
| Flask | Web backend | Lightweight routing and JSON API |
| SQLite | Database | Serverless persistent relational storage; no separate DB server required |
| HTML/CSS | Page and styling | Browser-native presentation |
| JavaScript | Client behaviour | Calls APIs and updates the dashboard without reloading |
| SVG | Graph illustration | Scalable network diagram with route highlighting |

## 7. Functional workflow

1. The user selects source, destination and optimization metric.
2. The browser sends a request to Flask.
3. Flask validates the request.
4. The backend reads cities and routes from SQLite.
5. The engine bridge exports a temporary graph file.
6. The C executable loads the graph and runs Dijkstra.
7. C returns a JSON result.
8. Flask saves successful journey history and returns JSON.
9. JavaScript renders the route, metrics and highlighted graph path.

## 8. Database design

- `cities`: unique city names and creation timestamps.
- `routes`: source/destination city references, distance, estimated duration, estimated fare and transport mode.
- `journey_history`: source, destination, metric, algorithm, route path and aggregate route metrics.

Foreign keys protect route references. SQL values are passed using parameterized queries. Numeric route weights are checked for non-negative values.

## 9. Input and output

**Inputs:** source city, destination city, metric; or city/route details when editing the network.

**Outputs:** selected path, total distance, estimated duration, estimated fare, number of graph connections, BFS path or DFS reachable-city order.

## 10. Testing

C engine unit tests cover route metrics, same-city paths, case-insensitive lookup, unknown cities, disconnected graphs and invalid graph files. Database tests cover initial sample seeding, persistence and duplicate connections. Flask tests cover API responses and validation. JavaScript syntax is checked with Node.js.

See `FINAL_QA_REPORT.md` for the exact checks run in the packaging environment and checks still required on Windows.

## 11. Limitations and future scope

This academic prototype uses a small sample graph. Travel durations and fares are illustrative estimates. The visual graph is schematic rather than geographic. Further work could add user accounts, richer map-based incident overlays, accessibility preferences, cloud deployment, and more operator-specific realtime adapters. Provider-dependent live traffic and transit data are only available where an authorized feed/API provides coverage.

## 12. Conclusion

The project combines core data structures and graph algorithms in C with a Flask/SQLite web application. It demonstrates separation of concerns: algorithmic computation, API orchestration, persistent storage and user interface are handled by distinct components while retaining the team's original C foundation.


## Live Public Transit Extension

The final release includes a configurable GTFS Schedule and GTFS-Realtime module. It imports operator stop, route, trip, stop-time and service-calendar data into SQLite; supports namespaced multi-operator imports; computes scheduled earliest-arrival journeys with up to three transfers; and parses official GTFS-Realtime vehicle positions, trip updates and service alerts. The dashboard shows vehicle markers on a map, provider status, feed freshness, alerts and realtime trip delay/cancellation overlays when identifiers match.

Live data is provider-dependent. No private API keys are bundled. Delhi Open Transit Data documents static Delhi bus GTFS and an authorized realtime vehicle-position endpoint. The portal warns that static bus arrival/departure times are rough estimates. No Dehradun/Uttarakhand realtime feed is bundled or claimed. See `LIVE_TRANSIT_SETUP.md`.

## 13. Live road-traffic extension

A separate HERE-powered road-traffic module is included. The browser submits place names or a search-area coordinate to Flask. The traffic service geocodes route endpoints, requests time-aware driving alternatives from HERE Routing API v8, and compares traffic-aware duration with the provider's free-flow `baseDuration` when the complete baseline is available. A separate HERE Traffic API v7 request returns flow speeds, free-flow speeds, jam factor, traversability, confidence/source classification, and road incidents for a selected circular search area. The HERE API key is stored only in the user's local `.env` file and is never included in the project ZIP or returned by the status endpoint.

This traffic provider integration is independent of the C graph engine and GTFS transit module. The C engine continues to calculate the original academic sample-graph routes; HERE calculates traffic-aware real-world road routes. Traffic requests are user-triggered to limit API usage. See `LIVE_TRAFFIC_SETUP.md`.

## 14. Scope and data integrity notes

HERE time-aware routing can use current traffic and historical traffic patterns. The app therefore labels the result as a traffic-aware estimate, not a guarantee. Flow confidence is shown because a flow speed can be derived from real-time probe data, historical traffic or speed-limit estimates. A missing free-flow baseline is shown as unavailable rather than fabricated. Traffic and transit provider coverage, account permissions, API quotas and possible charges depend on the relevant operator/provider and location. No private HERE key or live feed is bundled.
