# DSA and Viva Preparation Guide

## 1. What is the project?

Smart Journey Planner models locations and direct travel connections as an undirected weighted graph. It uses Dijkstra to select a route by distance, estimated time or estimated fare. BFS finds a route with the fewest graph edges, and DFS explores reachable cities. The C engine is connected to a Flask API and SQLite database and presented through a browser dashboard.

## 2. Core concepts to explain

**Vertex:** a city/location represented in the graph.  
**Edge:** a direct connection between two cities.  
**Weight:** a numeric value associated with an edge, such as kilometres, minutes or rupees.  
**Undirected graph:** a connection can be traversed in either direction.  
**Weighted graph:** edges carry values used for route comparison.  
**Adjacency list:** each vertex stores a list of its neighbours.  
**Min-heap:** a priority structure that returns the smallest-priority item first.  
**Hash table:** maps a city name to its graph index for quick lookup.

## 3. Algorithms

### Dijkstra

1. Set the source distance to zero and all other tentative distances to infinity.
2. Insert the source into a min-heap.
3. Remove the city with the smallest tentative distance.
4. Examine its outgoing edges and calculate candidate distances.
5. If a candidate is smaller, update the neighbour's distance and predecessor and push the updated item.
6. Continue until the heap is empty or the destination is finalized.
7. Follow predecessor links to reconstruct the route.

Dijkstra requires non-negative edge weights. This project validates weights accordingly.

### BFS

BFS uses a queue and visits vertices level by level. In an unweighted graph it finds a path with the minimum number of edges. In this project, “fewest connections” means fewest graph edges, not fewest bus/train transfers.

### DFS

DFS explores one branch as deeply as possible before backtracking. It is useful for discovering which cities are reachable from a starting city. The project uses it for reachability exploration, not weighted shortest-path calculation.

## 4. Why multiple metrics?

A traveller may prioritize distance, time or cost. Dijkstra is run with the corresponding edge weight. The selected path can therefore differ for different optimization criteria. The time and fare values in the sample graph are illustrative.

## 5. Common viva questions and model answers

**Q1. Why did you use a graph?**  
Because cities and direct connections naturally form vertices and edges. A graph can represent multiple possible paths between locations.

**Q2. Why use an adjacency list instead of an adjacency matrix?**  
For a sparse graph, an adjacency list stores only existing edges and is generally more memory-efficient.

**Q3. Why is a min-heap used in Dijkstra?**  
It efficiently selects the unprocessed vertex with the smallest tentative distance.

**Q4. Can Dijkstra handle negative weights?**  
No. Its correctness relies on non-negative edge weights, so the application rejects negative values.

**Q5. What is the difference between BFS and DFS?**  
BFS explores level by level and can find a minimum-edge path in an unweighted graph. DFS explores deeply along a branch before backtracking.

**Q6. Does BFS find the cheapest route?**  
No. BFS minimizes the number of edges, not the sum of edge weights. Dijkstra is used for weighted optimization.

**Q7. Why is SQLite used?**  
It stores cities, connections and journey history persistently in a local database file without requiring a separate database server.

**Q8. Why use Flask?**  
Flask provides HTTP routes and JSON APIs that connect the browser interface to the database and C engine.

**Q9. Does Python calculate the shortest path?**  
No. Python validates requests, exports the current database graph and invokes the C executable. The C engine performs Dijkstra, BFS and DFS.

**Q10. How are new cities and routes used by C?**  
The backend reads the latest SQLite records and writes a temporary graph data file. The C engine loads that file before calculating a route.

**Q11. What is the purpose of journey history?**  
It stores successful route searches so users can review previous calculations.

**Q12. Are fares and travel times live?**  
No. They are illustrative sample estimates and must not be represented as live or guaranteed travel information.

## 6. Honest project demonstration

Show the working website, run the three Dijkstra metrics, demonstrate BFS and DFS, add a city and connection, then show that the route network updates. Explain that the graph display is schematic and the sample duration/fare values are illustrative.
