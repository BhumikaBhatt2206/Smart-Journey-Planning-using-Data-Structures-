# Stage 3 Implementation Report – C Algorithm Engine

## 1. Purpose

Upgrade the original BINARY BRAINS C Journey Planning System into a modular, reusable C engine without discarding the original graph, heap, or Dijkstra concepts.

## 2. What was preserved

| Original project | Stage 3 treatment |
|---|---|
| Eight original city names | Preserved |
| Twelve original undirected connections | Preserved |
| `addRouteOneWay()` / `addRoute()` concepts | Retained as `graph_add_route_one_way()` / `graph_add_route()` |
| `heapPush()` / `heapPop()` | Retained as dynamic `heap_push()` / `heap_pop()` |
| `findLocation()` | Replaced by faster case-insensitive `graph_find_city()` using a hash table |
| `findShortestRoute()` | Refactored into reusable `dijkstra_route()` |
| Previous-array path reconstruction | Improved with predecessor data and an explicit stack |

The original file is retained in `docs/Journey_Planning_Binary_Brains_original.c` for comparison.

## 3. New modules

- `graph.c/.h`: dynamic graph, pointer-based adjacency lists, city hash table, route validation, and graph display.
- `min_heap.c/.h`: dynamically growing binary min heap.
- `algorithms.c/.h`: Dijkstra, BFS, DFS, path reconstruction, and route result management.
- `engine_cli.c`: interactive demonstration and JSON command-line interface for future backend integration.

## 4. How each algorithm is used

### Dijkstra

The same shortest-path idea from the original program is generalized to three non-negative edge weights:

- Distance mode: edge distance in kilometres.
- Time mode: estimated duration in minutes.
- Fare mode: estimated fare in rupees.

The algorithm maintains a tentative best value for every city, repeatedly removes the minimum-priority city from the min heap, and relaxes its outgoing edges. The stale-entry check is retained: if a popped heap priority no longer equals the best known distance, that entry is skipped.

### BFS

BFS uses a queue and visits cities in increasing number of edges from the source. The resulting route has the fewest connections when every edge is treated equally. It does not yet mean fewest transport transfers.

### DFS

DFS uses an explicit stack to explore all cities reachable from a starting city. This is useful for connectivity analysis.

### Hash table

City names are stored in an open-addressed hash table with linear probing. Lookup is average O(1), subject to normal hash-table assumptions. City matching is case-insensitive.

### Stack

An explicit dynamic stack reverses the predecessor chain into source-to-destination order during route reconstruction.

## 5. Route weights and data integrity

Dijkstra's algorithm requires non-negative weights. Route insertion rejects negative and non-finite distance, duration, or fare values. The sample distances are preserved from the original project. Time and fare values were added only as synthetic demonstration estimates; they are not verified transport quotes, live schedules, or booking information.

## 6. Complexity

Let V be the number of cities and E the number of directed adjacency-list edges.

| Algorithm / operation | Complexity |
|---|---|
| Dijkstra with duplicate heap entries | O((V + E) log E) worst-case heap work |
| BFS | O(V + E) |
| DFS | O(V + E) |
| Hash lookup | Average O(1), worst O(V) |
| Path reconstruction | O(V) |
| Add adjacency edge | O(1) |

## 7. Verification performed

The engine was compiled in the development environment with:

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -O2 -o journey_engine c_engine/engine_cli.c c_engine/graph.c c_engine/algorithms.c c_engine/min_heap.c
```

The automated Python test suite covers:

1. Original Dehradun-to-Delhi shortest distance (250 km).
2. Original Dehradun-to-Meerut shortest distance (180 km).
3. Fastest estimated route selection.
4. Cheapest estimated route selection.
5. BFS fewest-connections route.
6. DFS reachability.
7. Same-city route (zero cost).
8. Unknown city rejection.
9. Case-insensitive city lookup.
10. Disconnected destination.
11. Negative edge rejection.
12. Duplicate city rejection.
13. Non-finite edge rejection.
14. Exact duplicate connection rejection.

## 8. Limitations remaining

- The current graph loader uses a simple pipe-delimited file for demonstration and backend handoff; SQLite integration is Stage 4.
- Edges are undirected in the current graph API.
- Each connection currently has one transport mode.
- BFS minimizes edges, not changes in transport mode.
- Alternative k-shortest routes, A*, live transport feeds, and real map routing are not part of this stage.
- The Stage 3 package contains source code and Windows build scripts, not a prebuilt Windows executable. The executable must be compiled on the user's Windows computer using GCC.
