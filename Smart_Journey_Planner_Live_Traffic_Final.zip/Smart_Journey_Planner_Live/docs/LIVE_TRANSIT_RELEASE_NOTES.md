# Live Transit Release Notes

This release preserves the prior C engine, Flask road planner, SQLite database, web dashboard, history and DSA explorer, and adds:

1. GTFS Schedule ZIP import with validation.
2. Multiple operator schedule imports using namespaced IDs.
3. GTFS-Realtime Protocol Buffer readers for Vehicle Positions, Trip Updates and Service Alerts.
4. GTFS `transfers.txt` import and manual bidirectional walking links between separate operators.
5. Provider freshness/error status.
6. Leaflet map with OpenStreetMap attribution and live vehicle markers.
7. Scheduled public-transit itinerary search with up to three changes.
8. Bus/metro/rail/tram/ferry route type labels from GTFS route_type.
9. Matching realtime delay/cancellation overlay when trip IDs align.
10. Delhi OTD provider configuration template; realtime requires operator authorization and an API key.

Read `LIVE_TRANSIT_SETUP.md` before enabling operator feeds.
