# Final Release Notes

## Consolidated stages

- **Stage 3 — C engine:** modular graph engine, dynamic adjacency lists, min-heap, city hash lookup, Dijkstra, BFS, DFS, route path reconstruction and JSON CLI.
- **Stage 4 — Backend/database:** Flask API, SQLite persistence and C process bridge.
- **Stage 5 — Frontend:** responsive dashboard, SVG graph, route planner, DSA explorer, city/route forms and journey history.
- **Stage 6 — Quality hardening:** input bounds and validation, local-only non-debug server mode, API error responses, test instructions and troubleshooting.
- **Stage 7 — Final release:** consolidated folder, one-click Windows setup, standalone C demo, test runner, user guide, project report, viva guide and QA report.

## Important build detail

This archive is source-complete and contains all files needed to build and run the application on Windows when Python 3.10+, MinGW-w64 GCC and first-run internet access are available. A Windows `.exe` is not pre-bundled because the build environment used to prepare this archive does not have a Windows cross-compiler. `run_windows.bat` compiles `journey_engine.exe` locally on the Windows computer. The C engine was compiled with strict warnings and tested in the preparation environment as a native Linux executable.

## Verification summary

- C compiler: GCC 14.2, strict C11 warning flags including `-Werror` — build succeeded.
- Python syntax compilation — succeeded.
- JavaScript syntax check with Node.js — succeeded.
- Automated test discovery — 31 tests total; 21 passed, 10 Flask integration tests skipped because Flask could not be installed in the offline preparation environment.
- C smoke tests — shortest distance, fastest estimated time, cheapest estimated fare, BFS and DFS returned expected JSON.
- Windows website launch and Flask integration remain to be confirmed on the user's computer.


## Live road traffic update

Added HERE-powered road traffic support: geocoding, time-aware driving route alternatives, traffic delay versus free-flow comparison, road flow speeds, jam factor, confidence/source classification, traversability and incident summaries. New APIs: `/api/traffic/status`, `/api/traffic/route`, `/api/traffic/area`. Configure `HERE_API_KEY` in `.env`; no key is bundled and no traffic is simulated. See `LIVE_TRAFFIC_SETUP.md`.
