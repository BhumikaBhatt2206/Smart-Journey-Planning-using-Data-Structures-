# Live Road Traffic Setup Guide

## What this upgrade adds

The road-traffic module is separate from GTFS public-transit feeds. It uses the HERE Maps Platform APIs:

- **HERE Geocoding & Search API:** converts the origin and destination place names entered in the dashboard into coordinates.
- **HERE Routing API v8:** calculates time-aware driving routes using current and historical traffic information where available. It returns traffic-aware duration and, when the provider supplies it, a `baseDuration` without time-aware effects. The app compares these values to estimate the traffic-related delay.
- **HERE Traffic API v7 – Flow:** returns road-segment speed, free-flow speed, jam factor, traversability and confidence. Speeds are converted from metres per second to km/h.
- **HERE Traffic API v7 – Incidents:** returns incidents such as accidents, construction, congestion, disabled vehicles, road hazards and road closures where available.

The provider documentation explains that time-aware routing uses time-dependent information including live traffic and historical patterns. Flow confidence greater than 0.7 indicates real-time probe data; confidence between 0.5 and 0.7 indicates historical traffic; lower confidence may reflect speed-limit data. The dashboard labels these distinctions rather than calling every speed observation live.

## 1. Create a HERE API key

1. Open [HERE platform](https://platform.here.com/).
2. Sign in or create an account.
3. Open Access Manager / Apps and register an application.
4. Open the app's Credentials tab and create an API key.
5. Check the HERE account's enabled products, usage quota, pricing and terms. Do not assume every endpoint is enabled on every plan.

Official guides: [HERE Routing API getting started](https://docs.here.com/routing/docs/routing-v8-get-started), [HERE Traffic API getting started](https://docs.here.com/traffic-api/docs/send-request-readme), [Traffic in routing](https://docs.here.com/routing/docs/routing-v8-traffic-in-routing).

## 2. Add the key to the project

1. Open the extracted `Smart_Journey_Planner_Live` project folder.
2. Find `.env.example`.
3. Make a copy in the same folder and name the copy `.env`. If `.env` already exists for your GTFS credentials, edit that existing file instead of replacing it.
4. Add this line, replacing the placeholder with your actual key:

```text
HERE_API_KEY=your_private_here_api_key
```

5. Save the file. Do not add quotation marks unless your provider key itself contains them (normally it does not).
6. Restart the website by closing the previous server with Ctrl+C and double-clicking `run_windows.bat` again.

The `.env` file is excluded by `.gitignore`. Never publish it, send it in screenshots, or commit it to GitHub.

## 3. Calculate a traffic-aware route

1. Open `http://127.0.0.1:5000`.
2. Scroll to **Live road traffic & delay monitor**.
3. Enter an origin and destination, for example `Dehradun ISBT, Dehradun, India` and `Clock Tower, Dehradun, India`.
4. Click **Calculate with current traffic**.
5. Compare each alternative's traffic-aware duration, free-flow baseline, estimated delay and distance.

If HERE does not return a free-flow baseline, the delay field is shown as unavailable instead of inventing a number. Route estimates are based on the provider's data at request time and can change while travelling.

## 4. Inspect congestion and incidents near an area

The default search centre is the Dehradun Clock Tower area (30.3165, 78.0322). Change the latitude, longitude and radius as needed, then click **Find nearby traffic**.

- **Jam factor:** 0 means no congestion; values closer to 10 indicate increasing congestion; 10 represents a blocked road.
- **Current speed / free-flow speed:** returned by HERE in metres per second and displayed in km/h.
- **Confidence/source:** greater than 0.7 is real-time probe-based; greater than 0.5 and up to 0.7 is historical traffic; 0.5 or below may be speed-limit estimates.
- **Traversability:** the provider's open/closed status when supplied.
- **Incidents:** event type, criticality, road name and description when the provider supplies them.

Search radius must be between 1 km and 50 km.

## 5. API endpoints added

- `GET /api/traffic/status` — indicates whether a HERE key is configured (never returns the key).
- `POST /api/traffic/route` — JSON body: `{"origin":"...","destination":"..."}`.
- `POST /api/traffic/area` — JSON body: `{"latitude":30.3165,"longitude":78.0322,"radius_m":10000}`.

Traffic API requests are user-triggered; the app does not automatically poll HERE, helping avoid unnecessary API consumption. The existing 30-second GTFS-Realtime polling is independent.

## 6. Error handling and limitations

- **API KEY REQUIRED:** `.env` is missing, the key is blank, or the server has not been restarted after editing it.
- **401 / 403:** key rejected, service not enabled, or account lacks access.
- **429:** provider request quota or rate limit reached.
- **No route found:** HERE could not calculate a driving route for the supplied locations.
- **No flow / incident results:** no matching data was returned for the selected area; it does not prove that every road is clear.
- **Delay unavailable:** the routing response did not contain the free-flow `baseDuration`; no delay is fabricated.
- Coverage and real-time probe density vary by location. If confidence indicates historical or speed-limit data, the interface labels it accordingly.
- This module covers road-traffic data; it does not make GTFS transit feeds live or provide a universal live traffic feed for every Indian city.
- HERE account access, API quotas, billing and terms may change. Check the provider's current platform console before regular use.
