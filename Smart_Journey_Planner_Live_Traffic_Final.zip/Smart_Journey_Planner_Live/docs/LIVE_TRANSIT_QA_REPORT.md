# Live Transit Upgrade – QA Report

## Checks executed in the build environment

- C engine compiled successfully with GCC using the existing Makefile.
- Original C engine tests: 14 passed.
- Existing SQLite/backend bridge tests: 5 passed.
- New GTFS tests: 7 passed (static import, stop search, multi-leg transfer journey, multi-operator ID prefix merge, invalid ZIP rejection, and honest unconfigured-realtime status).
- JavaScript syntax check passed with Node.js.
- Python syntax compilation passed for Flask app, backend modules and transit tests.

Combined non-Flask test run: **26 passed**.

## Not verified here

- Flask is not installed in the build environment, so Flask route/client tests and a live browser session were not executed.
- No Delhi OTD API key or other operator credentials were supplied. Therefore no real vehicle positions, trip updates or alerts could be fetched during QA.
- Windows batch files and Windows GCC compilation must be confirmed on the user's Windows computer.
- No real operator GTFS ZIP was supplied. GTFS import and multi-leg planning were tested using generated test feeds, not an operator's production timetable.

## Data honesty

A provider with no configured URL is shown as NOT_CONFIGURED. A fetched feed without a timestamp is AGE UNKNOWN. A stale feed is labelled stale. Static timetable results are not described as live vehicle tracking.
