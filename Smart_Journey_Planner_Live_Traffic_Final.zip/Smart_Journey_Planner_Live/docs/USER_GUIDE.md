# User Guide — Windows

## A. Install prerequisites

1. Install Python 3.10+ from python.org. Enable the Python Launcher and PATH options.
2. Install a MinGW-w64 GCC toolchain. Add its `bin` folder to the Windows PATH.
3. Open a new Command Prompt and verify `py --version` and `gcc --version`.

## B. Start the website

1. Extract the project ZIP to a normal folder, for example `C:\Users\YourName\Documents\Smart_Journey_Planner_Final`.
2. Double-click `run_windows.bat`.
3. On the first run, it builds the C executable, creates `.venv`, and installs Flask. Internet access is required for Flask installation.
4. Open `http://127.0.0.1:5000` in a browser.
5. Keep the terminal window open. Stop the server with Ctrl+C.

## C. Dashboard walkthrough

1. Select Dehradun as the source and Delhi as the destination.
2. Choose **Shortest / Distance** and calculate. The original direct 250 km sample edge should be selected.
3. Choose **Fastest / Estimated time** and calculate. The sample data should choose Dehradun → Meerut → Delhi (330 minutes).
4. Choose **Cheapest / Estimated fare**. The sample data should choose Dehradun → Meerut → Delhi (₹850).
5. Observe the selected route highlighted in the graph and the successful search in Journey History.
6. Run BFS from Dehradun to Shimla. It should show a path with two edges through Chandigarh.
7. Run DFS from Dehradun to see reachable cities.
8. Add a new city, then add a connection to it. Run a route search to see that the C engine uses the newly stored SQLite network.
9. Clear history if desired. This does not delete cities or routes.

## D. Standalone C demo

Double-click `run_demo_windows.bat`; this opens the menu-driven C console application.

## E. Preserve your work

The database is stored at `data\journey_planner.db`. Back up that file before moving or replacing the project folder. The project ZIP deliberately does not include a pre-populated database, so the initial sample map is seeded on first run.

## F. Common errors

- `gcc is not recognized`: fix GCC PATH and reopen Command Prompt.
- `py is not recognized`: reinstall Python with its launcher enabled.
- Flask installation fails: check internet, then run `.venv\Scripts\python.exe -m pip install -r requirements.txt`.
- Port conflict: in Command Prompt run `set PORT=5001` then `run_windows.bat`; open port 5001.
- Missing engine: run `build_windows.bat` from the project folder.

## Live public transit

See `LIVE_TRANSIT_SETUP.md` for the complete setup. In short: import an official GTFS Schedule ZIP in the Live Transit Centre, set an operator prefix, and configure official GTFS-Realtime HTTPS URLs in `config/transit_feeds.json`. Copy `.env.example` to `.env` and put private credentials there. The same prefix must be used for the operator's timetable import and realtime feed configuration.

A timetable can be imported without live tracking. Vehicle locations, delay predictions and service alerts are displayed only when the relevant operator provides and authorizes those realtime feeds. The app labels missing or stale feeds; do not describe scheduled estimates as live tracking.


## Live road traffic monitor

1. Create a HERE Maps Platform API key (see `docs/LIVE_TRAFFIC_SETUP.md`).
2. Copy `.env.example` to `.env` in the project root, or edit the existing `.env` without deleting transit credentials.
3. Add `HERE_API_KEY=your_private_key` and restart `run_windows.bat`.
4. Open **Live road traffic & delay monitor**.
5. Use **Calculate with current traffic** to compare the traffic-aware route time with the free-flow baseline for two place names.
6. Use **Find nearby traffic** to inspect road speeds, jam factor, confidence/source and incidents within the selected radius.

No HERE key means traffic requests are unavailable; no fake or sample congestion is displayed. Keep `.env` private.
