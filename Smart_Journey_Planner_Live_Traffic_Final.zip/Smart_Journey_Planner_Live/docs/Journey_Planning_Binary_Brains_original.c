#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/*
 * Journey Planning using Data Structures
 * Team: BINARY BRAINS
 * Graph + adjacency lists + min-priority queue + Dijkstra's algorithm.
 */

#define MAX_LOCATIONS 8
#define MAX_NAME 40
#define MAX_EDGES 32
#define INF (LLONG_MAX / 4)

typedef struct {
    int to, distance, next;
} Edge;

typedef struct {
    int location;
    long long distance;
} HeapNode;

typedef struct {
    HeapNode items[MAX_EDGES * 4];
    int size;
} MinHeap;

static const char *locations[MAX_LOCATIONS] = {
    "Dehradun", "Mussoorie", "Haridwar", "Rishikesh",
    "Delhi", "Chandigarh", "Shimla", "Meerut"
};
static Edge edges[MAX_EDGES];
static int head[MAX_LOCATIONS];
static int edgeCount = 0;

static void addRouteOneWay(int from, int to, int distance) {
    if (edgeCount >= MAX_EDGES) {
        fprintf(stderr, "Route storage is full.\n");
        exit(EXIT_FAILURE);
    }
    edges[edgeCount] = (Edge){to, distance, head[from]};
    head[from] = edgeCount++;
}

static void addRoute(int a, int b, int distance) {
    addRouteOneWay(a, b, distance);
    addRouteOneWay(b, a, distance);
}

static void heapPush(MinHeap *heap, int location, long long distance) {
    if (heap->size >= (int)(sizeof(heap->items) / sizeof(heap->items[0]))) {
        fprintf(stderr, "Priority queue is full.\n");
        exit(EXIT_FAILURE);
    }
    int i = heap->size++;
    heap->items[i] = (HeapNode){location, distance};

    while (i > 0) {
        int parent = (i - 1) / 2;
        if (heap->items[parent].distance <= heap->items[i].distance) break;
        HeapNode temp = heap->items[parent];
        heap->items[parent] = heap->items[i];
        heap->items[i] = temp;
        i = parent;
    }
}

static HeapNode heapPop(MinHeap *heap) {
    HeapNode result = heap->items[0];
    heap->size--;
    if (heap->size == 0) return result;

    heap->items[0] = heap->items[heap->size];
    int i = 0;
    while (1) {
        int left = 2 * i + 1, right = 2 * i + 2, smallest = i;
        if (left < heap->size &&
            heap->items[left].distance < heap->items[smallest].distance)
            smallest = left;
        if (right < heap->size &&
            heap->items[right].distance < heap->items[smallest].distance)
            smallest = right;
        if (smallest == i) break;

        HeapNode temp = heap->items[i];
        heap->items[i] = heap->items[smallest];
        heap->items[smallest] = temp;
        i = smallest;
    }
    return result;
}

static int findLocation(const char *name) {
    for (int i = 0; i < MAX_LOCATIONS; i++)
        if (strcmp(name, locations[i]) == 0) return i;
    return -1;
}

static void showLocations(void) {
    printf("\nAvailable locations:\n");
    for (int i = 0; i < MAX_LOCATIONS; i++)
        printf("  %d. %s\n", i + 1, locations[i]);
}

static void showRoutes(void) {
    printf("\nSample direct routes (illustrative distances in km):\n");
    for (int from = 0; from < MAX_LOCATIONS; from++) {
        for (int e = head[from]; e != -1; e = edges[e].next) {
            int to = edges[e].to;
            if (from < to)
                printf("  %-12s <-> %-12s : %d km\n",
                       locations[from], locations[to], edges[e].distance);
        }
    }
}

static void findShortestRoute(int source, int destination) {
    long long distance[MAX_LOCATIONS];
    int previous[MAX_LOCATIONS], visited[MAX_LOCATIONS] = {0};
    MinHeap heap = {.size = 0};

    for (int i = 0; i < MAX_LOCATIONS; i++) {
        distance[i] = INF;
        previous[i] = -1;
    }
    distance[source] = 0;
    heapPush(&heap, source, 0);

    while (heap.size > 0) {
        HeapNode current = heapPop(&heap);
        int u = current.location;
        if (visited[u] || current.distance != distance[u]) continue;

        visited[u] = 1;
        if (u == destination) break;

        for (int e = head[u]; e != -1; e = edges[e].next) {
            int v = edges[e].to;
            if (!visited[v] && distance[u] + edges[e].distance < distance[v]) {
                distance[v] = distance[u] + edges[e].distance;
                previous[v] = u;
                heapPush(&heap, v, distance[v]);
            }
        }
    }

    if (distance[destination] == INF) {
        printf("\nNo route found between %s and %s.\n",
               locations[source], locations[destination]);
        return;
    }

    int path[MAX_LOCATIONS], pathLength = 0;
    for (int at = destination; at != -1; at = previous[at]) {
        if (pathLength >= MAX_LOCATIONS) {
            printf("The route could not be reconstructed.\n");
            return;
        }
        path[pathLength++] = at;
    }

    printf("\nShortest route:\n  ");
    for (int i = pathLength - 1; i >= 0; i--) {
        printf("%s", locations[path[i]]);
        if (i > 0) printf(" -> ");
    }
    printf("\nTotal distance: %lld km\n", distance[destination]);
}

static void buildSampleMap(void) {
    for (int i = 0; i < MAX_LOCATIONS; i++) head[i] = -1;

    addRoute(0, 1, 34);   /* Dehradun - Mussoorie */
    addRoute(0, 2, 52);   /* Dehradun - Haridwar */
    addRoute(0, 3, 45);   /* Dehradun - Rishikesh */
    addRoute(0, 4, 250);  /* Dehradun - Delhi */
    addRoute(0, 5, 170);  /* Dehradun - Chandigarh */
    addRoute(1, 3, 67);   /* Mussoorie - Rishikesh */
    addRoute(2, 3, 25);   /* Haridwar - Rishikesh */
    addRoute(2, 7, 150);  /* Haridwar - Meerut */
    addRoute(4, 7, 70);   /* Delhi - Meerut */
    addRoute(4, 5, 245);  /* Delhi - Chandigarh */
    addRoute(5, 6, 115);  /* Chandigarh - Shimla */
    addRoute(0, 7, 180);  /* Dehradun - Meerut */
}

int main(void) {
    char sourceName[MAX_NAME], destinationName[MAX_NAME];
    int choice;
    buildSampleMap();

    printf("========================================\n");
    printf("  JOURNEY PLANNING USING DATA STRUCTURES\n");
    printf("             BINARY BRAINS\n");
    printf("========================================\n");

    while (1) {
        printf("\nMenu\n1. Find shortest route\n2. Show locations\n");
        printf("3. Show sample routes\n4. Exit\nEnter choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Enter a menu number.\n");
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF) { }
            continue;
        }

        if (choice == 1) {
            showLocations();
            printf("\nEnter source exactly as listed: ");
            if (scanf(" %39[^\n]", sourceName) != 1) {
                printf("Could not read source.\n");
                continue;
            }
            printf("Enter destination exactly as listed: ");
            if (scanf(" %39[^\n]", destinationName) != 1) {
                printf("Could not read destination.\n");
                continue;
            }

            int source = findLocation(sourceName);
            int destination = findLocation(destinationName);
            if (source == -1 || destination == -1) {
                printf("Location not recognized. Check the spelling in the list.\n");
            } else if (source == destination) {
                printf("You are already at %s. Total distance: 0 km\n",
                       locations[source]);
            } else {
                findShortestRoute(source, destination);
            }
        } else if (choice == 2) {
            showLocations();
        } else if (choice == 3) {
            showRoutes();
        } else if (choice == 4) {
            printf("Thank you for using Journey Planning. Goodbye!\n");
            break;
        } else {
            printf("Invalid choice. Select 1, 2, 3, or 4.\n");
        }
    }
    return 0;
}
