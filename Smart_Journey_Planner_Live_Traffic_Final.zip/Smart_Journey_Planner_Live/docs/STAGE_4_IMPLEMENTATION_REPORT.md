# Stage 4 Implementation Report – Backend and Database Integration

Team: **BINARY BRAINS**

## Objective

Connect the existing Stage 3 C graph engine to a Python Flask backend and SQLite database without rewriting the route algorithms in Python.

## Architecture

1. **Frontend:** HTML, CSS and JavaScript dashboard in `templates/` and `static/`.
2. **Backend:** Flask routes in `app.py` validate requests and return JSON.
3. **Database:** SQLite tables `cities` and `routes` persist the graph data.
4. **C algorithm engine:** Existing executable runs Dijkstra, BFS and DFS.
5. **Bridge:** `backend/engine_bridge.py` reads SQLite records, exports a temporary Stage 3-compatible graph file, invokes the C executable with `subprocess`, parses its JSON output, and returns the result to Flask.

## Why this preserves the C project

The C files from Stage 3 remain in `c_engine/` unchanged. The C engine still owns graph construction and Dijkstra/BFS/DFS calculations. Python does not duplicate those algorithms; it only handles HTTP, persistence, validation, and process coordination.

## SQLite schema

- `cities`: unique city name and primary key.
- `routes`: source and destination foreign keys, distance, estimated duration, estimated fare, and transport mode.
- Foreign-key checks and non-negative numeric constraints are enabled.
- The seed database contains the same eight cities and twelve sample connections as Stage 3.
- A route row represents one undirected connection; export to the C format uses `EDGE` records, and the existing `graph_add_route` function adds both directions.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Check backend stack |
| GET | `/api/cities` | List saved cities |
| POST | `/api/cities` | Add a city |
| GET | `/api/routes` | List saved connections |
| POST | `/api/routes` | Add a connection |
| GET | `/api/route?source=...&destination=...&metric=distance\|time\|fare` | Run C Dijkstra |
| GET | `/api/bfs?source=...&destination=...` | Run C BFS |
| GET | `/api/dfs?source=...` | Run C DFS |

## Run on Windows

1. Extract the project ZIP.
2. Install Python 3.10 or newer and GCC/MinGW-w64. Ensure `py` and `gcc` work in Command Prompt.
3. Double-click `run_windows.bat`. It builds the C engine if needed, creates `.venv`, installs Flask from `requirements.txt`, initializes the SQLite database, and starts Flask.
4. Open `http://127.0.0.1:5000` in a browser.
5. Keep the Command Prompt window open while using the site. Press `Ctrl+C` to stop the server.

First-time setup requires internet access to install Flask. After successful installation, normal launches reuse the virtual environment and local SQLite database. The launcher currently checks/installs requirements on every launch, but does not recreate the database if it already exists.

## Important limitations

- The sample time and fare values are illustrative estimates, not live travel information.
- The sample network is not a live map or navigation service.
- This stage has a working dashboard and API, but does not yet include user accounts, authentication, deployment, maps, bookings, or live traffic.
- The C engine is launched as a local subprocess for each calculation. This is straightforward and auditable for a college project; a future production deployment could use a persistent native service or Python C binding.
- Windows execution must be confirmed on the student's own machine. Development validation in this environment is not a substitute for testing on Windows.

## Validation performed during package preparation

- The C engine compiled with GCC using `-std=c11 -Wall -Wextra -Wpedantic -Werror -O2`.
- All 14 existing Stage 3 C-engine tests passed.
- Four SQLite persistence/validation tests and one SQLite-to-C bridge test passed.
- Combined test discovery reported 19 passed and 8 Flask integration tests skipped because Flask could not be installed in the package-preparation environment (outbound package access was unavailable). Those 8 tests are included and will run after `pip install -r requirements.txt` on the user's computer.
- Python source files passed `py_compile`; browser JavaScript passed `node --check`.
- The SQLite-to-C bridge was exercised directly for Dijkstra, BFS and DFS, including a newly inserted city and route.
- Windows execution has not yet been verified on the user's Windows laptop.
