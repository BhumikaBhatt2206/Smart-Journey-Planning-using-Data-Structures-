@echo off
setlocal
cd /d "%~dp0"
title Smart Journey Planner - Binary Brains

echo ============================================================
echo       SMART JOURNEY PLANNER - FINAL WINDOWS RELEASE
echo       C Engine ^| Flask Backend ^| SQLite ^| Web Dashboard
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/
  echo During installation, enable the Python Launcher and Add Python to PATH.
  pause
  exit /b 1
)
where gcc >nul 2>nul
if errorlevel 1 (
  echo ERROR: GCC was not found.
  echo Install a MinGW-w64 GCC toolchain and add its bin folder to PATH.
  echo Then reopen this window and run this file again.
  pause
  exit /b 1
)

py -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
  echo ERROR: Python 3.10 or newer is required.
  pause
  exit /b 1
)

if not exist "journey_engine.exe" (
  echo [1/3] Building the C route engine...
  call build_windows.bat --no-pause
  if errorlevel 1 (
    echo ERROR: C engine build failed.
    pause
    exit /b 1
  )
) else (
  echo [1/3] C engine executable found.
)

if not exist ".venv\Scripts\python.exe" (
  echo [2/3] Creating the Python virtual environment...
  py -m venv .venv
  if errorlevel 1 (
    echo ERROR: Could not create the Python environment.
    pause
    exit /b 1
  )
) else (
  echo [2/3] Python virtual environment found.
)

".venv\Scripts\python.exe" -c "import flask, dotenv; from google.transit import gtfs_realtime_pb2" >nul 2>nul
if errorlevel 1 (
  echo [3/3] Installing Flask and transit-feed libraries. Internet access is required for first setup...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  if errorlevel 1 goto :install_failed
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto :install_failed
) else (
  echo [3/3] Flask is already installed.
)

echo.
echo Starting the website at http://127.0.0.1:5000
echo Keep this window open while using the website.
echo Press Ctrl+C here to stop the server.
echo.
".venv\Scripts\python.exe" app.py
pause
exit /b 0

:install_failed
echo ERROR: Flask installation failed. Check internet access and retry.
echo You can also run: .venv\Scripts\python.exe -m pip install -r requirements.txt
pause
exit /b 1
