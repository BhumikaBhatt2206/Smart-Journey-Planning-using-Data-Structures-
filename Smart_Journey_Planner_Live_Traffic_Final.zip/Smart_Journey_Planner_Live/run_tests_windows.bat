@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run run_windows.bat once first to create the Python environment.
  pause
  exit /b 1
)
if not exist "journey_engine.exe" call build_windows.bat --no-pause
if not exist "journey_engine.exe" exit /b 1
".venv\Scripts\python.exe" -m unittest discover -s tests -v
set TEST_RESULT=%ERRORLEVEL%
echo.
if "%TEST_RESULT%"=="0" (echo Test run completed.) else (echo One or more tests failed.)
pause
exit /b %TEST_RESULT%
