@echo off
cd /d "%~dp0"
if not exist "journey_engine.exe" call build_windows.bat --no-pause
if not exist "journey_engine.exe" (
  echo C engine is unavailable. Check the compiler setup.
  pause
  exit /b 1
)
echo Running the standalone C demonstration menu...
journey_engine.exe demo
pause
