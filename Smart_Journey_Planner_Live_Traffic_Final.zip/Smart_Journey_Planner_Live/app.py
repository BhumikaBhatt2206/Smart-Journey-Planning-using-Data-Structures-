"""Flask application for the Smart Journey Planner."""
from __future__ import annotations

import math
import os
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from backend.database import (add_city, add_route, initialize_database, list_cities, list_routes,
                              list_journey_history, save_journey_history)
from backend.engine_bridge import EngineError, run_engine
from backend.transit import fetch_live, import_gtfs_zip, search_stops, next_departures, transit_summary, plan_transit, add_transit_transfer, list_transit_transfers
from backend.traffic import TrafficProviderError, traffic_aware_route, traffic_area, traffic_provider_status

ROOT = Path(__file__).resolve().parent


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(
        DATABASE=str(ROOT / "data" / "journey_planner.db"),
        JSON_SORT_KEYS=False,
    )
    if test_config:
        app.config.update(test_config)
    initialize_database(app.config["DATABASE"])
    app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024

    @app.get("/")
    def home():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "application": "Smart Journey Planner", "backend": "Flask", "database": "SQLite", "algorithm_engine": "C", "transit_standard": "GTFS + GTFS-Realtime"})

    @app.get("/api/cities")
    def cities():
        return jsonify({"status": "ok", "cities": list_cities(app.config["DATABASE"])})

    @app.post("/api/cities")
    def create_city():
        body = request.get_json(silent=True) or {}
        name = body.get("name")
        if (not isinstance(name, str) or not name.strip() or len(name.strip()) >= 100
                or any(ch in name for ch in "|\r\n") or any(ord(ch) < 32 for ch in name)):
            return jsonify({"status": "error", "message": "Enter a valid city name (1–99 characters; no | or new lines)."}), 400
        try:
            city = add_city(name, app.config["DATABASE"])
            return jsonify({"status": "ok", "city": city}), 201
        except Exception as exc:
            if "UNIQUE" in str(exc).upper():
                return jsonify({"status": "error", "message": "That city already exists."}), 409
            raise

    @app.get("/api/routes")
    def routes():
        return jsonify({"status": "ok", "routes": list_routes(app.config["DATABASE"])})

    @app.post("/api/routes")
    def create_route():
        body = request.get_json(silent=True) or {}
        source, destination = body.get("source"), body.get("destination")
        if not isinstance(source, str) or not isinstance(destination, str) or not source.strip() or not destination.strip():
            return jsonify({"status": "error", "message": "Source and destination city names are required."}), 400
        numeric = {}
        for field in ("distance_km", "duration_min", "fare_rupees"):
            value = body.get(field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                return jsonify({"status": "error", "message": f"{field} must be a non-negative number."}), 400
            if value > 1000000000:
                return jsonify({"status": "error", "message": f"{field} is outside the supported range."}), 400
            numeric[field] = float(value)
        if source.strip().casefold() == destination.strip().casefold():
            return jsonify({"status": "error", "message": "A connection must join two different cities."}), 400
        mode = body.get("transport_mode", "Road")
        if (not isinstance(mode, str) or not mode.strip() or len(mode.strip()) >= 24
                or any(ch in mode for ch in "|\r\n") or any(ord(ch) < 32 for ch in mode)):
            return jsonify({"status": "error", "message": "Enter a valid transport mode (1–23 characters)."}), 400
        try:
            route = add_route(source, destination, numeric["distance_km"], numeric["duration_min"], numeric["fare_rupees"], mode, app.config["DATABASE"])
            return jsonify({"status": "ok", "route": route}), 201
        except ValueError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 400

    @app.get("/api/route")
    def calculate_route():
        source = request.args.get("source", "").strip()
        destination = request.args.get("destination", "").strip()
        metric = request.args.get("metric", "distance").lower()
        if not source or not destination:
            return jsonify({"status": "error", "message": "source and destination are required."}), 400
        if metric not in {"distance", "time", "fare"}:
            return jsonify({"status": "error", "message": "metric must be distance, time or fare."}), 400
        try:
            result = run_engine(app.config["DATABASE"], "route", source, destination, metric)
            status_code = 200 if result.get("status") == "ok" else 404
            if result.get("status") == "ok":
                save_journey_history(source, destination, metric, result, app.config["DATABASE"])
            return jsonify(result), status_code
        except EngineError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 503

    # HERE live road traffic integration (separate from public-transit GTFS feeds).
    @app.get("/api/traffic/status")
    def traffic_status():
        return jsonify({"status": "ok", **traffic_provider_status()})

    @app.post("/api/traffic/route")
    def traffic_route():
        body = request.get_json(silent=True) or {}
        origin, destination = body.get("origin"), body.get("destination")
        if not isinstance(origin, str) or not isinstance(destination, str):
            return jsonify({"status": "error", "message": "Enter both origin and destination place names."}), 400
        try:
            result = traffic_aware_route(origin, destination)
            return jsonify(result)
        except ValueError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 400
        except TrafficProviderError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 503

    @app.post("/api/traffic/area")
    def traffic_area_data():
        body = request.get_json(silent=True) or {}
        try:
            latitude, longitude = float(body.get("latitude")), float(body.get("longitude"))
            radius = int(body.get("radius_m", 10000))
            result = traffic_area(latitude, longitude, radius)
            return jsonify(result)
        except (TypeError, ValueError) as exc:
            return jsonify({"status": "error", "message": str(exc) or "Enter valid coordinates."}), 400
        except TrafficProviderError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 503

    # GTFS Schedule + GTFS Realtime public-transit integration.
    @app.get("/api/transit/summary")
    def transit_data_summary():
        return jsonify({"status": "ok", **transit_summary(app.config["DATABASE"])})

    @app.get("/api/transit/live")
    def transit_live():
        try:
            return jsonify({"status": "ok", **fetch_live(app.config["DATABASE"])})
        except Exception as exc:
            return jsonify({"status": "error", "message": str(exc)}), 503

    @app.post("/api/transit/import")
    def transit_import():
        uploaded = request.files.get("gtfs_file")
        if not uploaded or not uploaded.filename.lower().endswith(".zip"):
            return jsonify({"status": "error", "message": "Choose a GTFS Schedule ZIP file."}), 400
        try:
            prefix = request.form.get('prefix', '').strip()
            merge = request.form.get('merge') == 'true'
            result = import_gtfs_zip(uploaded.read(), app.config["DATABASE"], prefix=prefix, merge=merge)
            return jsonify({"status": "ok", "imported": result}), 200
        except (ValueError, KeyError, OSError) as exc:
            return jsonify({"status": "error", "message": str(exc)}), 400

    @app.get("/api/transit/transfers")
    def transit_transfers():
        return jsonify({"status": "ok", "transfers": list_transit_transfers(app.config["DATABASE"])})

    @app.post("/api/transit/transfers")
    def create_transit_transfer():
        body = request.get_json(silent=True) or {}
        source, destination = body.get("from_stop_id"), body.get("to_stop_id")
        minutes = body.get("walking_minutes")
        if not isinstance(source, str) or not isinstance(destination, str) or not source or not destination:
            return jsonify({"status": "error", "message": "Choose both stops."}), 400
        if isinstance(minutes, bool) or not isinstance(minutes, (int, float)) or not math.isfinite(minutes):
            return jsonify({"status": "error", "message": "Walking minutes must be a number."}), 400
        try:
            result = add_transit_transfer(source, destination, minutes, app.config["DATABASE"])
            return jsonify({"status": "ok", "transfer": result}), 201
        except ValueError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 400

    @app.get("/api/transit/stops")
    def transit_stops():
        query = request.args.get("q", "").strip()
        if request.args.get("all") == "1":
            query = "%"
        elif len(query) < 2:
            return jsonify({"status": "ok", "stops": []})
        return jsonify({"status": "ok", "stops": search_stops(query, app.config["DATABASE"], limit=10000 if query == "%" else 12)})

    @app.get("/api/transit/departures")
    def transit_departures():
        stop_id = request.args.get("stop_id", "").strip()
        if not stop_id:
            return jsonify({"status": "error", "message": "stop_id is required."}), 400
        return jsonify({"status": "ok", "departures": next_departures(stop_id, app.config["DATABASE"])})

    @app.get("/api/transit/plan")
    def transit_plan():
        origin = request.args.get("from_stop_id", "").strip()
        destination = request.args.get("to_stop_id", "").strip()
        if not origin or not destination:
            return jsonify({"status": "error", "message": "Choose origin and destination stops."}), 400
        try:
            result = plan_transit(origin, destination, app.config["DATABASE"])
            return jsonify(result), (200 if result.get("status") == "ok" else 404)
        except ValueError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 400

    @app.get("/api/history")
    def journey_history():
        return jsonify({"status": "ok", "history": list_journey_history(app.config["DATABASE"])})

    @app.delete("/api/history")
    def clear_journey_history():
        from backend.database import database_connection
        with database_connection(app.config["DATABASE"]) as connection:
            connection.execute("DELETE FROM journey_history")
        return jsonify({"status": "ok", "message": "Journey history cleared."})

    @app.get("/api/bfs")
    def breadth_first_route():
        source, destination = request.args.get("source", "").strip(), request.args.get("destination", "").strip()
        if not source or not destination:
            return jsonify({"status": "error", "message": "source and destination are required."}), 400
        try:
            result = run_engine(app.config["DATABASE"], "bfs", source, destination)
            return jsonify(result), (200 if result.get("status") == "ok" else 404)
        except EngineError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 503

    @app.get("/api/dfs")
    def depth_first_exploration():
        source = request.args.get("source", "").strip()
        if not source:
            return jsonify({"status": "error", "message": "source is required."}), 400
        try:
            result = run_engine(app.config["DATABASE"], "dfs", source)
            return jsonify(result), (200 if result.get("status") == "ok" else 404)
        except EngineError as exc:
            return jsonify({"status": "error", "message": str(exc)}), 503

    @app.errorhandler(404)
    def not_found(_error):
        if request.path.startswith("/api/"):
            return jsonify({"status": "error", "message": "API endpoint not found."}), 404
        return "Page not found.", 404

    @app.errorhandler(500)
    def internal_error(_error):
        if request.path.startswith("/api/"):
            return jsonify({"status": "error", "message": "An internal server error occurred."}), 500
        return "An internal server error occurred.", 500

    return app


app = create_app()

if __name__ == "__main__":
    # Local academic demonstration only. Debug mode is deliberately disabled.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
