@echo off
setlocal
cd /d "%~dp0"
where gcc >nul 2>nul
if errorlevel 1 (
  echo GCC was not found. Install MinGW-w64 and add its bin folder to PATH.
  if /i not "%~1"=="--no-pause" pause
  exit /b 1
)
echo Compiling the C graph and algorithm engine...
gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -O2 -o journey_engine.exe c_engine\engine_cli.c c_engine\graph.c c_engine\algorithms.c c_engine\min_heap.c
if errorlevel 1 (
  echo Build failed. Review the compiler errors above.
  if /i not "%~1"=="--no-pause" pause
  exit /b 1
)
echo SUCCESS: journey_engine.exe has been created.
if /i not "%~1"=="--no-pause" pause
exit /b 0
