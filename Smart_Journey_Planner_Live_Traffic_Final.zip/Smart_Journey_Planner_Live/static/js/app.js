const $ = (id) => document.getElementById(id);
let cities = [], routes = [], lastPath = [];

async function api(url, options = {}) {
  const response = await fetch(url, {headers: {'Content-Type': 'application/json'}, ...options});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Request failed (${response.status})`);
  return data;
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function toast(message, isError = false) {
  const box = $('toast'); box.textContent = message; box.className = `toast show${isError ? ' error' : ''}`;
  window.clearTimeout(toast.timer); toast.timer = window.setTimeout(() => box.className = 'toast', 3200);
}
function fillCitySelect(select, selected) {
  const old = selected || select.value;
  select.innerHTML = '';
  cities.forEach(city => { const option = document.createElement('option'); option.value = city.name; option.textContent = city.name; select.appendChild(option); });
  if (cities.some(city => city.name === old)) select.value = old;
}
function renderCities() {
  ['source-city','destination-city','explore-city','new-route-source','new-route-destination'].forEach(id => fillCitySelect($(id)));
  if (cities.length > 1 && $('destination-city').selectedIndex === 0) $('destination-city').selectedIndex = 1;
  $('stat-cities').textContent = cities.length;
}
function renderRoutes() {
  $('stat-routes').textContent = routes.length;
  $('connection-count').textContent = `${routes.length} routes`;
  $('route-list').innerHTML = routes.map(r => `<tr><td>${escapeHtml(r.source)}</td><td>${escapeHtml(r.destination)}</td><td>${Number(r.distance_km).toFixed(1)} km</td><td>${Number(r.duration_min).toFixed(0)} min</td><td>₹${Number(r.fare_rupees).toFixed(0)}</td><td><span class="mode-pill">${escapeHtml(r.transport_mode)}</span></td></tr>`).join('') || '<tr><td colspan="6" class="empty-table">No connections have been added yet.</td></tr>';
  drawGraph();
}
function drawGraph(path = lastPath) {
  const svg = $('network-graph'), width = 620, height = 330, cx = width/2, cy = height/2, rx = 230, ry = 125;
  const positions = new Map();
  cities.forEach((city, i) => { const a = -Math.PI/2 + (2*Math.PI*i/Math.max(cities.length,1)); positions.set(city.name, {x:cx+rx*Math.cos(a), y:cy+ry*Math.sin(a)}); });
  const highlighted = new Set(); for (let i=1;i<path.length;i++) highlighted.add([path[i-1],path[i]].sort().join('|'));
  let markup = '';
  routes.forEach(route => { const a=positions.get(route.source), b=positions.get(route.destination); if(!a||!b)return; const hot=highlighted.has([route.source,route.destination].sort().join('|')); markup += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" class="edge${hot?' edge-hot':''}"/>`; });
  cities.forEach(city => { const p=positions.get(city.name), hot=path.includes(city.name); markup += `<g class="node${hot?' node-hot':''}"><circle cx="${p.x}" cy="${p.y}" r="${hot?9:7}"/><text x="${p.x}" y="${p.y+24}" text-anchor="middle">${escapeHtml(city.name)}</text></g>`; });
  svg.innerHTML = markup || '<text x="310" y="165" text-anchor="middle" class="graph-empty">Add cities and routes to build your network.</text>';
}
function showRoute(result) {
  const box=$('route-result');
  if(result.status!=='ok'){box.className='route-result placeholder';box.textContent='No connected route was found between these cities.';lastPath=[];drawGraph();return;}
  lastPath=result.path||[]; drawGraph(lastPath);
  box.className='route-result success';
  box.innerHTML=`<div class="result-top"><span class="success-chip">✓ ROUTE FOUND</span><span class="algorithm-chip">${escapeHtml(result.algorithm)} · ${escapeHtml(result.metric)}</span></div><div class="route-chain">${result.path.map((city,i)=>`${i?'<span class="chain-arrow">→</span>':''}<span class="route-stop">${escapeHtml(city)}</span>`).join('')}</div><div class="result-metrics"><div><b>${Number(result.distance_km).toFixed(1)}<small> km</small></b><span>Total distance</span></div><div><b>${Number(result.duration_min).toFixed(0)}<small> min</small></b><span>Estimated time</span></div><div><b>₹${Number(result.fare_rupees).toFixed(0)}</b><span>Estimated fare</span></div><div><b>${result.connections}</b><span>Connections</span></div></div>`;
  loadHistory();
}
async function loadHistory(){
  try { const data=await api('/api/history'); $('history-list').innerHTML=data.history.length?data.history.map(item=>`<div class="history-item"><span class="history-icon">↗</span><div><b>${escapeHtml(item.source)} <i>→</i> ${escapeHtml(item.destination)}</b><small>${escapeHtml(item.algorithm)} · ${escapeHtml(item.metric)} · ${escapeHtml(item.created_at||'Saved journey')}</small></div><strong>${Number(item.distance_km).toFixed(0)} km</strong></div>`).join(''):'<div class="empty-state">No saved journeys yet. Calculate a route to start your history.</div>'; }
  catch(e){$('history-list').textContent='Could not load journey history.';}
}
async function refreshData(){
  const [cityData,routeData]=await Promise.all([api('/api/cities'),api('/api/routes')]);
  const currentSource=$('source-city').value,currentDestination=$('destination-city').value;
  cities=cityData.cities;routes=routeData.routes;renderCities();
  if(currentSource) $('source-city').value=currentSource;
  if(currentDestination) $('destination-city').value=currentDestination;
  renderRoutes();
}
async function loadDashboard(){
  const health=await api('/api/health');
  $('system-status').textContent=`${health.backend} · ${health.database} · ${health.algorithm_engine} online`;
  await refreshData(); await loadHistory();
}
$('find-route').addEventListener('click',async()=>{
  if(!$('source-city').value||!$('destination-city').value)return toast('Add at least two cities first.',true);
  const button=$('find-route');button.disabled=true;button.innerHTML='<span>Finding best route…</span><span>◌</span>';
  try{const params=new URLSearchParams({source:$('source-city').value,destination:$('destination-city').value,metric:document.querySelector('input[name="metric"]:checked').value});showRoute(await api(`/api/route?${params}`));}
  catch(e){toast(e.message,true);}finally{button.disabled=false;button.innerHTML='<span>Calculate best route</span><span>→</span>';}
});
$('swap-cities').addEventListener('click',()=>{const a=$('source-city').value,b=$('destination-city').value;$('source-city').value=b;$('destination-city').value=a;});
document.querySelectorAll('.metric-option').forEach(label=>label.addEventListener('click',()=>{document.querySelectorAll('.metric-option').forEach(x=>x.classList.remove('selected'));label.classList.add('selected');}));
$('run-bfs').addEventListener('click',async()=>{try{const p=new URLSearchParams({source:$('explore-city').value,destination:$('destination-city').value});const r=await api(`/api/bfs?${p}`);$('explore-result').textContent=r.status==='ok'?`BFS traversal result: ${r.path.join(' → ')} · ${r.connections} connections`:'No route found.';lastPath=r.path||[];drawGraph(lastPath);}catch(e){$('explore-result').textContent=e.message;}});
$('run-dfs').addEventListener('click',async()=>{try{const p=new URLSearchParams({source:$('explore-city').value});const r=await api(`/api/dfs?${p}`);$('explore-result').textContent=r.status==='ok'?`DFS reachable-city order: ${r.reachable.join(' → ')}`:'DFS could not complete.';}catch(e){$('explore-result').textContent=e.message;}});
$('add-city-form').addEventListener('submit',async e=>{e.preventDefault();try{await api('/api/cities',{method:'POST',body:JSON.stringify({name:$('new-city-name').value.trim()})});$('new-city-name').value='';await refreshData();toast('City added to your SQLite database.');$('management-message').textContent='City saved successfully.';}catch(err){toast(err.message,true);}});
$('add-route-form').addEventListener('submit',async e=>{e.preventDefault();try{const body={source:$('new-route-source').value,destination:$('new-route-destination').value,distance_km:Number($('new-route-distance').value),duration_min:Number($('new-route-time').value),fare_rupees:Number($('new-route-fare').value),transport_mode:$('new-route-mode').value.trim()};await api('/api/routes',{method:'POST',body:JSON.stringify(body)});e.target.reset();$('new-route-mode').value='Road';await refreshData();toast('Connection saved. The C engine will use it on the next search.');}catch(err){toast(err.message,true);}});
$('clear-history').addEventListener('click',async()=>{try{await api('/api/history',{method:'DELETE'});await loadHistory();toast('Journey history cleared.');}catch(e){toast(e.message,true);}});
loadDashboard().catch(e=>{$('system-status').textContent=`Service error: ${e.message}`;toast(e.message,true);});

// GTFS public-transit module. Live data is shown only when an operator feed is configured.
let transitMap = null, transitMarkers = null, transitStops = [], transitRealtime = {vehicles:[],alerts:[],trip_updates:[]};
function initTransitMap(){
  const el=$('transit-map'); if(!el || !window.L || transitMap) return;
  el.innerHTML='';
  transitMap=L.map(el).setView([30.3165,78.0322],8);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(transitMap);
  transitMarkers=L.layerGroup().addTo(transitMap);
}
function renderTransitSummary(summary){
  $('gtfs-summary').textContent=`${summary.stops} stops · ${summary.routes} transit routes · ${summary.trips} trips · ${summary.transfers} transfer links · ${summary.providers_configured} live providers configured`;
}
async function loadTransitStops(){
  const data=await api('/api/transit/stops?all=1'); transitStops=data.stops||[];
  ['transit-origin','transit-destination','transfer-from','transfer-to'].forEach((id,index)=>{
    const select=$(id),old=select.value;select.innerHTML='<option value="">Select a stop</option>';
    transitStops.forEach(stop=>{const option=document.createElement('option');option.value=stop.stop_id;option.textContent=`${stop.stop_name} · ${stop.stop_id}`;select.appendChild(option);});
    if(transitStops.some(s=>s.stop_id===old))select.value=old;
    else if(transitStops.length>index)select.selectedIndex=Math.min(index+1,transitStops.length);
  });
}
function renderLiveData(data){
  transitRealtime=data;
  $('live-updated').textContent=`Updated ${new Date(data.fetched_at*1000).toLocaleTimeString()}`;
  $('provider-status').innerHTML=(data.providers||[]).map(p=>{
    const state=p.status==='error'?'error':p.freshness==='stale'?'stale':p.status==='live'?'live':'';
    const detail=`${p.vehicle_count} vehicles · ${p.trip_update_count} trip updates · ${p.alert_count} alerts`;
    const freshness=p.freshness==='stale'?' · FEED STALE':p.freshness==='fresh'?' · FRESH':' · AGE UNKNOWN';
    return `<div class="provider-item"><div><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(detail)}${escapeHtml(freshness)}${p.errors?.length?' · '+escapeHtml(p.errors.join('; ')):''}</small></div><span class="provider-state ${state}">${escapeHtml(p.status.toUpperCase())}</span></div>`;
  }).join('') || '<div class="empty-state">No providers configured. Add official feed URLs to config/transit_feeds.json.</div>';
  $('transit-alerts').innerHTML=(data.alerts||[]).map(a=>`<div class="alert-item"><strong>${escapeHtml(a.header||'Transit service alert')}</strong><p>${escapeHtml(a.description||'No additional description supplied.')}</p><small>${escapeHtml(a.provider||'Provider')} · ${escapeHtml(a.effect||'Status update')}</small></div>`).join('') || '<div class="empty-state">No active service alerts were returned by configured feeds.</div>';
  initTransitMap();
  if(transitMarkers){transitMarkers.clearLayers();(data.vehicles||[]).forEach(v=>{
    if(!Number.isFinite(v.latitude)||!Number.isFinite(v.longitude))return;
    const marker=L.marker([v.latitude,v.longitude]).bindPopup(`<b>${escapeHtml(v.label||v.id||'Transit vehicle')}</b><br>${escapeHtml(v.route_id||'Route not supplied')}<br>${escapeHtml(v.provider||'')}`);marker.addTo(transitMarkers);
  });}
  if((data.vehicles||[]).length){const pts=data.vehicles.filter(v=>Number.isFinite(v.latitude)&&Number.isFinite(v.longitude)).map(v=>[v.latitude,v.longitude]);if(pts.length)transitMap.fitBounds(pts,{padding:[25,25],maxZoom:13});}
}
async function loadTransitTransfers(){
  try{const data=await api('/api/transit/transfers');$('transfer-list').innerHTML=(data.transfers||[]).filter((t,i)=>t.from_stop_id<t.to_stop_id).map(t=>`<span class="transfer-pill">${escapeHtml(t.from_name)} ↔ ${escapeHtml(t.to_name)} · ${Math.round(t.min_transfer_seconds/60)} min walk</span>`).join('')||'No inter-operator walking links added.';}
  catch(e){$('transfer-list').textContent=e.message;}
}
async function refreshTransit(){
  try{const data=await api('/api/transit/live');renderLiveData(data);}
  catch(e){$('provider-status').textContent=`Could not retrieve transit feeds: ${e.message}`;}
}
async function loadTransitSummary(){
  try{const summary=await api('/api/transit/summary');renderTransitSummary(summary);if(summary.stops){await loadTransitStops();await loadTransitTransfers();}}
  catch(e){$('gtfs-summary').textContent=e.message;}
}
$('import-gtfs')?.addEventListener('click',async()=>{
  const file=$('gtfs-file').files[0];if(!file)return toast('Choose a GTFS Schedule ZIP file first.',true);
  const form=new FormData();form.append('gtfs_file',file);form.append('prefix',$('gtfs-prefix').value.trim());form.append('merge',$('gtfs-merge').checked?'true':'false');
  const button=$('import-gtfs');button.disabled=true;button.textContent='Importing…';
  try{const response=await fetch('/api/transit/import',{method:'POST',body:form});const result=await response.json();if(!response.ok)throw new Error(result.message||'GTFS import failed');
    toast(`Imported ${result.imported.stops} stops and ${result.imported.trips} trips.`);await loadTransitSummary();
  }catch(e){toast(e.message,true);}finally{button.disabled=false;button.textContent='Import timetable';}
});
$('refresh-live')?.addEventListener('click',refreshTransit);
$('plan-transit')?.addEventListener('click',async()=>{
  const from=$('transit-origin').value,to=$('transit-destination').value;
  if(!from||!to)return toast('Import a timetable and choose both stops.',true);
  const button=$('plan-transit');button.disabled=true;button.textContent='Searching…';
  try{const params=new URLSearchParams({from_stop_id:from,to_stop_id:to});const result=await api(`/api/transit/plan?${params}`);
    if(result.status!=='ok'){$('transit-plan-result').textContent=result.message||'No itinerary found.';return;}
    const updates=new Map((transitRealtime.trip_updates||[]).map(u=>[u.trip_id,u]));
    const legs=result.legs.map(leg=>{const update=updates.get(leg.trip_id);const delay=update?.departure_delay;
      const delayText=update?.trip_status==='3'?' · CANCELED (live feed)':Number.isFinite(delay)?` · realtime delay ${Math.round(delay/60)} min`:' · no realtime update';
      return `<div class="transit-leg"><time>${escapeHtml(leg.departure)}<small>to ${escapeHtml(leg.arrival)}</small></time><div><b>${escapeHtml(leg.mode||'Transit')} · ${escapeHtml(leg.route_name)} → ${escapeHtml(leg.headsign||leg.to_stop)}</b><small>${escapeHtml(leg.from_stop)} → ${escapeHtml(leg.to_stop)}${escapeHtml(delayText)}</small></div></div>`;
    }).join('');
    $('transit-plan-result').innerHTML=`<b>${escapeHtml(result.origin)} → ${escapeHtml(result.destination)}</b><p>${result.transfers} transfer(s) · ${escapeHtml(result.departure)} departure · ${escapeHtml(result.arrival)} arrival</p>${legs}<small>${escapeHtml(result.disclaimer)}</small>`;
  }catch(e){$('transit-plan-result').textContent=e.message;}finally{button.disabled=false;button.textContent='Find transit journey →';}
});
$('add-transfer')?.addEventListener('click',async()=>{
  const body={from_stop_id:$('transfer-from').value,to_stop_id:$('transfer-to').value,walking_minutes:Number($('transfer-minutes').value)};
  try{await api('/api/transit/transfers',{method:'POST',body:JSON.stringify(body)});await loadTransitTransfers();toast('Bidirectional walking transfer saved. It can connect separate bus/metro feeds.');}
  catch(e){toast(e.message,true);}
});
loadTransitSummary().then(refreshTransit);
// Poll configured operator feeds every 30 seconds; each refresh still labels stale data.
window.setInterval(refreshTransit, 30000);

// HERE live road-traffic module. Requests are user-triggered to avoid unexpected API usage.
function renderTrafficRoute(data){
  const box=$('traffic-route-result');
  const routes=data.routes||[];
  if(!routes.length){box.textContent='No route alternatives were returned.';return;}
  box.innerHTML=`<div><b>${escapeHtml(data.origin.label)} → ${escapeHtml(data.destination.label)}</b><small style="display:block;color:var(--muted);margin-top:3px">${escapeHtml(data.provider)} · requested ${new Date(data.queried_at*1000).toLocaleTimeString()}</small></div>`+
    routes.map(route=>`<div class="traffic-route-option"><strong>Route option ${route.option}${route.option===1?' · fastest with current traffic':''}</strong><div class="traffic-metrics"><div class="traffic-metric"><b>${route.traffic_duration_minutes} min</b><span>Traffic-aware time</span></div><div class="traffic-metric"><b>${route.free_flow_duration_minutes===null?'—':route.free_flow_duration_minutes+' min'}</b><span>Free-flow baseline</span></div><div class="traffic-metric"><b>${route.traffic_delay_minutes===null?'—':route.traffic_delay_minutes+' min'}</b><span>Estimated traffic delay</span></div><div class="traffic-metric"><b>${route.distance_km} km</b><span>Distance</span></div></div>${route.delay_percent===null?'':`<small>Traffic adds approximately ${route.delay_percent}% compared with the free-flow baseline.</small>`}</div>`).join('')+
    `<small>${escapeHtml(data.disclaimer||'')}</small>`;
}
function renderTrafficArea(data){
  const box=$('traffic-area-result');
  const incidents=data.incidents||[], flows=data.flows||[];
  const incidentHtml=incidents.length?incidents.map(item=>`<div class="traffic-list-item"><b>${escapeHtml(item.type)} · ${escapeHtml(item.criticality)}</b><small>${escapeHtml(item.road_name)} — ${escapeHtml(item.description)}</small></div>`).join(''):'<div class="traffic-list-item">No incidents were returned in this search area.</div>';
  const flowHtml=flows.length?flows.slice(0,20).map(item=>`<div class="traffic-list-item"><b>${escapeHtml(item.road_name)} · Jam factor ${item.jam_factor===null?'not supplied':item.jam_factor+'/10'}</b><small>Current speed: ${item.current_speed_kph===null?'not supplied':item.current_speed_kph+' km/h'} · Free-flow speed: ${item.free_flow_speed_kph===null?'not supplied':item.free_flow_speed_kph+' km/h'} · ${escapeHtml(item.confidence_source||'source not specified')} · ${escapeHtml(item.traversability||'status unknown')}</small></div>`).join(''):'<div class="traffic-list-item">No road-flow segments were returned in this search area.</div>';
  box.innerHTML=`<b>${data.incident_count} incidents · ${data.flow_count} road-flow segments</b><small style="display:block;color:var(--muted);margin:3px 0 10px">${escapeHtml(data.provider)} · ${new Date(data.queried_at*1000).toLocaleTimeString()} · ${data.radius_m/1000} km radius · Source updated: ${escapeHtml(data.flow_source_updated||'not supplied')}</small><div class="traffic-subtitle">INCIDENTS & ROAD CLOSURES</div><div class="traffic-list">${incidentHtml}</div><div class="traffic-subtitle" style="margin-top:14px">CONGESTION & ROAD SPEEDS (FIRST 20)</div><div class="traffic-list">${flowHtml}</div><small style="display:block;margin-top:10px">${escapeHtml(data.disclaimer||'')}</small>`;
}
async function checkTrafficConfiguration(){
  try{const result=await api('/api/traffic/status');const badge=$('traffic-connection');if(result.configured){badge.textContent='HERE API KEY CONFIGURED';badge.className='traffic-status-badge ready';}else{badge.textContent='API KEY REQUIRED';badge.className='traffic-status-badge';}}
  catch(_){$('traffic-connection').textContent='STATUS UNAVAILABLE';$('traffic-connection').className='traffic-status-badge error';}
}
$('traffic-route-form')?.addEventListener('submit',async event=>{
  event.preventDefault();const button=$('traffic-route-button');button.disabled=true;button.textContent='Checking current road traffic…';$('traffic-route-result').textContent='Requesting current traffic-aware route estimates from HERE…';
  try{const result=await api('/api/traffic/route',{method:'POST',body:JSON.stringify({origin:$('traffic-origin').value.trim(),destination:$('traffic-destination').value.trim()})});renderTrafficRoute(result);}
  catch(error){$('traffic-route-result').textContent=error.message;toast(error.message,true);}
  finally{button.disabled=false;button.textContent='Calculate with current traffic →';}
});
$('traffic-area-form')?.addEventListener('submit',async event=>{
  event.preventDefault();const button=$('traffic-area-button');button.disabled=true;button.textContent='Loading traffic…';$('traffic-area-result').textContent='Fetching live road flow and incident data…';
  try{const result=await api('/api/traffic/area',{method:'POST',body:JSON.stringify({latitude:Number($('traffic-lat').value),longitude:Number($('traffic-lon').value),radius_m:Number($('traffic-radius').value)})});renderTrafficArea(result);}
  catch(error){$('traffic-area-result').textContent=error.message;toast(error.message,true);}
  finally{button.disabled=false;button.textContent='Find nearby traffic';}
});
checkTrafficConfiguration();
