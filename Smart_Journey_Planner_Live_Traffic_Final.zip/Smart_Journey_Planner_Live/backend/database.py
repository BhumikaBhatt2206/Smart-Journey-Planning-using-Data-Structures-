"""SQLite setup and data-access helpers for Smart Journey Planner."""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DB_PATH = ROOT / "data" / "journey_planner.db"


def get_connection(db_path: str | Path = DEFAULT_DB_PATH) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


@contextmanager
def database_connection(db_path: str | Path = DEFAULT_DB_PATH):
    """Yield a connection and always close it after the transaction."""
    connection = get_connection(db_path)
    try:
        with connection:
            yield connection
    finally:
        connection.close()


def initialize_database(db_path: str | Path = DEFAULT_DB_PATH) -> None:
    """Create tables and seed the original Stage 3 sample map once."""
    with database_connection(db_path) as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS cities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS routes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_city_id INTEGER NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
                destination_city_id INTEGER NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
                distance_km REAL NOT NULL CHECK(distance_km >= 0),
                duration_min REAL NOT NULL CHECK(duration_min >= 0),
                fare_rupees REAL NOT NULL CHECK(fare_rupees >= 0),
                transport_mode TEXT NOT NULL DEFAULT 'Road',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CHECK(source_city_id <> destination_city_id)
            );
            CREATE INDEX IF NOT EXISTS idx_routes_source ON routes(source_city_id);
            CREATE INDEX IF NOT EXISTS idx_routes_destination ON routes(destination_city_id);
            CREATE TABLE IF NOT EXISTS journey_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_name TEXT NOT NULL,
                destination_name TEXT NOT NULL,
                metric TEXT NOT NULL CHECK(metric IN ('distance', 'time', 'fare', 'bfs')),
                algorithm TEXT NOT NULL,
                path_json TEXT NOT NULL,
                distance_km REAL NOT NULL DEFAULT 0,
                duration_min REAL NOT NULL DEFAULT 0,
                fare_rupees REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_history_created ON journey_history(created_at DESC);
            """
        )
        count = connection.execute("SELECT COUNT(*) FROM cities").fetchone()[0]
        if count == 0:
            cities = [
                "Dehradun", "Mussoorie", "Haridwar", "Rishikesh",
                "Delhi", "Chandigarh", "Shimla", "Meerut",
            ]
            connection.executemany("INSERT INTO cities(name) VALUES (?)", [(name,) for name in cities])
            edges = [
                ("Dehradun", "Mussoorie", 34, 90, 250, "Road"),
                ("Dehradun", "Haridwar", 52, 95, 300, "Road"),
                ("Dehradun", "Rishikesh", 45, 75, 280, "Road"),
                ("Dehradun", "Delhi", 250, 360, 900, "Road"),
                ("Dehradun", "Chandigarh", 170, 300, 750, "Road"),
                ("Mussoorie", "Rishikesh", 67, 150, 400, "Road"),
                ("Haridwar", "Rishikesh", 25, 45, 150, "Road"),
                ("Haridwar", "Meerut", 150, 210, 650, "Road"),
                ("Delhi", "Meerut", 70, 90, 200, "Road"),
                ("Delhi", "Chandigarh", 245, 330, 850, "Road"),
                ("Chandigarh", "Shimla", 115, 180, 600, "Road"),
                ("Dehradun", "Meerut", 180, 240, 650, "Road"),
            ]
            ids = {row["name"]: row["id"] for row in connection.execute("SELECT id, name FROM cities")}
            connection.executemany(
                """INSERT INTO routes
                (source_city_id, destination_city_id, distance_km, duration_min, fare_rupees, transport_mode)
                VALUES (?, ?, ?, ?, ?, ?)""",
                [(ids[a], ids[b], distance, duration, fare, mode)
                 for a, b, distance, duration, fare, mode in edges],
            )


def list_cities(db_path: str | Path = DEFAULT_DB_PATH) -> list[dict]:
    with database_connection(db_path) as connection:
        rows = connection.execute("SELECT id, name FROM cities ORDER BY id").fetchall()
        return [dict(row) for row in rows]


def list_routes(db_path: str | Path = DEFAULT_DB_PATH) -> list[dict]:
    with database_connection(db_path) as connection:
        rows = connection.execute(
            """SELECT r.id, a.name AS source, b.name AS destination,
                      r.distance_km, r.duration_min, r.fare_rupees, r.transport_mode
               FROM routes r JOIN cities a ON a.id=r.source_city_id
               JOIN cities b ON b.id=r.destination_city_id ORDER BY r.id"""
        ).fetchall()
        return [dict(row) for row in rows]


def add_city(name: str, db_path: str | Path = DEFAULT_DB_PATH) -> dict:
    with database_connection(db_path) as connection:
        cursor = connection.execute("INSERT INTO cities(name) VALUES (?)", (name.strip(),))
        return {"id": cursor.lastrowid, "name": name.strip()}


def add_route(source: str, destination: str, distance: float, duration: float,
              fare: float, mode: str = "Road", db_path: str | Path = DEFAULT_DB_PATH) -> dict:
    with database_connection(db_path) as connection:
        source_row = connection.execute("SELECT id FROM cities WHERE name = ? COLLATE NOCASE", (source.strip(),)).fetchone()
        destination_row = connection.execute("SELECT id FROM cities WHERE name = ? COLLATE NOCASE", (destination.strip(),)).fetchone()
        if not source_row or not destination_row:
            raise ValueError("Both source and destination must be existing cities.")
        if source_row["id"] == destination_row["id"]:
            raise ValueError("A route must connect two different cities.")
        duplicate = connection.execute(
            """SELECT 1 FROM routes WHERE
               ((source_city_id=? AND destination_city_id=?) OR
                (source_city_id=? AND destination_city_id=?)) AND
               distance_km=? AND duration_min=? AND fare_rupees=? AND transport_mode=? LIMIT 1""",
            (source_row["id"], destination_row["id"], destination_row["id"], source_row["id"],
             distance, duration, fare, mode.strip()),
        ).fetchone()
        if duplicate:
            raise ValueError("An identical connection already exists.")
        cursor = connection.execute(
            """INSERT INTO routes(source_city_id, destination_city_id, distance_km,
                                  duration_min, fare_rupees, transport_mode)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (source_row["id"], destination_row["id"], distance, duration, fare, mode.strip()),
        )
        return {"id": cursor.lastrowid, "source": source.strip(), "destination": destination.strip(),
                "distance_km": distance, "duration_min": duration, "fare_rupees": fare,
                "transport_mode": mode.strip()}


def save_journey_history(source: str, destination: str, metric: str, result: dict,
                         db_path: str | Path = DEFAULT_DB_PATH) -> dict:
    """Persist a successful route calculation for the dashboard history."""
    import json
    with database_connection(db_path) as connection:
        cursor = connection.execute(
            """INSERT INTO journey_history
               (source_name, destination_name, metric, algorithm, path_json,
                distance_km, duration_min, fare_rupees)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (source, destination, metric, result.get("algorithm", "Dijkstra"),
             json.dumps(result.get("path", [])), float(result.get("distance_km", 0)),
             float(result.get("duration_min", 0)), float(result.get("fare_rupees", 0))),
        )
        return {"id": cursor.lastrowid, "source": source, "destination": destination,
                "metric": metric, "algorithm": result.get("algorithm", "Dijkstra"),
                "path": result.get("path", []), "distance_km": result.get("distance_km", 0),
                "duration_min": result.get("duration_min", 0), "fare_rupees": result.get("fare_rupees", 0)}

def list_journey_history(db_path: str | Path = DEFAULT_DB_PATH, limit: int = 10) -> list[dict]:
    import json
    with database_connection(db_path) as connection:
        rows = connection.execute(
            """SELECT id, source_name AS source, destination_name AS destination, metric,
                      algorithm, path_json, distance_km, duration_min, fare_rupees, created_at
               FROM journey_history ORDER BY id DESC LIMIT ?""", (max(1, min(int(limit), 50)),)
        ).fetchall()
        results = []
        for row in rows:
            item = dict(row)
            item["path"] = json.loads(item.pop("path_json"))
            results.append(item)
        return results
