"""HERE-powered live road traffic and traffic-aware driving routes.

Requires a HERE API key. No traffic values are simulated or cached as live data.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

HERE_GEOCODE = "https://geocode.search.hereapi.com/v1/geocode"
HERE_ROUTING = "https://router.hereapi.com/v8/routes"
HERE_FLOW = "https://data.traffic.hereapi.com/v7/flow"
HERE_INCIDENTS = "https://data.traffic.hereapi.com/v7/incidents"
USER_AGENT = "SmartJourneyPlanner-BinaryBrains/1.1"
ROOT = Path(__file__).resolve().parent.parent
try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
except ImportError:
    pass


class TrafficProviderError(RuntimeError):
    """Raised when HERE is unavailable, rejects credentials, or returns bad data."""


def _api_key(explicit_key: str | None = None) -> str:
    key = (explicit_key or os.getenv("HERE_API_KEY", "")).strip()
    if not key:
        raise TrafficProviderError(
            "Live road traffic is not configured. Add your HERE_API_KEY to the project's .env file."
        )
    return key


def _get_json(url: str, params: dict, timeout: int = 18) -> dict:
    request_url = f"{url}?{urlencode(params)}"
    request = Request(request_url, headers={"Accept": "application/json", "User-Agent": USER_AGENT})
    try:
        with urlopen(request, timeout=timeout) as response:
            payload = response.read()
        data = json.loads(payload.decode("utf-8"))
        if not isinstance(data, dict):
            raise TrafficProviderError("The traffic provider returned an unexpected response.")
        return data
    except HTTPError as exc:
        if exc.code in (401, 403):
            message = "HERE rejected the API key or the account does not have access to this service."
        elif exc.code == 429:
            message = "HERE request limit reached. Check your plan and try again later."
        else:
            message = f"HERE request failed (HTTP {exc.code})."
        raise TrafficProviderError(message) from exc
    except (URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise TrafficProviderError("Could not reach HERE traffic services. Check your internet connection and try again.") from exc


def geocode_place(place: str, api_key: str | None = None) -> dict:
    key = _api_key(api_key)
    place = str(place or "").strip()
    if len(place) < 3 or len(place) > 180:
        raise ValueError("Enter a place name or address between 3 and 180 characters.")
    data = _get_json(HERE_GEOCODE, {"q": place, "limit": 1, "apiKey": key})
    items = data.get("items") or []
    if not items:
        raise ValueError(f"Could not find a map location for: {place}")
    item = items[0]
    position = item.get("position") or {}
    lat, lon = position.get("lat"), position.get("lng")
    if not isinstance(lat, (int, float)) or not isinstance(lon, (int, float)):
        raise TrafficProviderError("The geocoding response did not contain valid coordinates.")
    return {"label": item.get("title") or place, "latitude": float(lat), "longitude": float(lon)}


def _route_summary(route: dict) -> dict:
    sections = route.get("sections") or []
    duration = sum(int((s.get("summary") or {}).get("duration", 0)) for s in sections)
    base_values = [(s.get("summary") or {}).get("baseDuration") for s in sections]
    base_duration = sum(int(v) for v in base_values if isinstance(v, (int, float)))
    length = sum(int((s.get("summary") or {}).get("length", 0)) for s in sections)
    baseline_complete = bool(base_values) and all(v is not None for v in base_values)
    delay = max(0, duration - base_duration) if baseline_complete else None
    if not baseline_complete:
        base_duration = 0
    return {
        "distance_km": round(length / 1000, 2),
        "traffic_duration_seconds": duration,
        "traffic_duration_minutes": round(duration / 60),
        "free_flow_duration_seconds": base_duration if baseline_complete else None,
        "free_flow_duration_minutes": round(base_duration / 60) if baseline_complete else None,
        "traffic_delay_seconds": delay,
        "traffic_delay_minutes": round(delay / 60) if delay is not None else None,
        "delay_percent": round((delay / base_duration) * 100, 1) if delay is not None and base_duration > 0 else None,
    }


def traffic_aware_route(origin: str, destination: str, api_key: str | None = None) -> dict:
    key = _api_key(api_key)
    start = geocode_place(origin, key)
    end = geocode_place(destination, key)
    params = {
        "transportMode": "car",
        "origin": f"{start['latitude']},{start['longitude']}",
        "destination": f"{end['latitude']},{end['longitude']}",
        "return": "summary,polyline",
        "alternatives": 2,
        "apiKey": key,
    }
    # HERE time-aware routing uses current traffic when no departureTime is supplied.
    data = _get_json(HERE_ROUTING, params)
    routes = data.get("routes") or []
    if not routes:
        raise ValueError("HERE could not find a driving route between these locations.")
    results = []
    for index, route in enumerate(routes):
        summary = _route_summary(route)
        results.append({
            "option": index + 1,
            **summary,
            "sections": len(route.get("sections") or []),
            "polyline": (route.get("sections") or [{}])[0].get("polyline"),
            "traffic_status": "time_aware_traffic_estimate" if summary["traffic_delay_seconds"] is not None else "traffic_adjusted_duration_available",
        })
    results.sort(key=lambda item: item["traffic_duration_seconds"])
    for rank, item in enumerate(results, start=1):
        item["option"] = rank
    return {
        "status": "ok",
        "traffic_mode": "time_aware_current_conditions",
        "provider": "HERE Routing API v8",
        "queried_at": int(time.time()),
        "origin": start,
        "destination": end,
        "routes": results,
        "disclaimer": "Traffic-aware estimates reflect HERE's current time-aware road data at request time. Conditions can change during travel.",
    }


def traffic_area(latitude: float, longitude: float, radius_m: int = 10000, api_key: str | None = None) -> dict:
    key = _api_key(api_key)
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        raise ValueError("Enter valid latitude and longitude coordinates.")
    if not (1000 <= radius_m <= 50000):
        raise ValueError("Traffic search radius must be between 1,000 and 50,000 metres.")
    area = f"circle:{latitude},{longitude};r={radius_m}"
    flow_data = _get_json(HERE_FLOW, {"in": area, "locationReferencing": "shape", "apiKey": key})
    incident_data = _get_json(HERE_INCIDENTS, {"in": area, "locationReferencing": "shape", "lang": "en-US", "apiKey": key})

    flows = []
    for item in flow_data.get("results", []):
        current = item.get("currentFlow") or {}
        free_flow_speed = current.get("freeFlow")
        jam = current.get("jamFactor")
        if jam is None:
            jam = current.get("jam_factor")
        location = item.get("location") or {}
        shape = location.get("shape") or {}
        confidence = current.get("confidence")
        if isinstance(confidence, (int, float)):
            confidence_source = "real-time probe data" if confidence > 0.7 else ("historical traffic model" if confidence > 0.5 else "speed-limit estimate")
        else:
            confidence_source = "source not specified"
        flows.append({
            "jam_factor": round(float(jam), 1) if isinstance(jam, (int, float)) else None,
            "current_speed_kph": round(float(current.get("speed", 0)) * 3.6, 1) if current.get("speed") is not None else None,
            "free_flow_speed_kph": round(float(free_flow_speed) * 3.6, 1) if free_flow_speed is not None else None,
            "confidence": confidence,
            "confidence_source": confidence_source,
            "traversability": current.get("traversability", "unknown"),
            "road_name": location.get("description") or location.get("roadName") or "Road segment",
            "shape": shape.get("links", []),
        })
    incidents = []
    for item in incident_data.get("results", []):
        details = item.get("incidentDetails") or {}
        description = details.get("description") or {}
        summary = details.get("summary") or {}
        location = item.get("location") or {}
        incidents.append({
            "id": item.get("incidentId") or item.get("id"),
            "type": details.get("type") or "traffic incident",
            "criticality": details.get("criticality") or "unknown",
            "description": description.get("value") or description.get("text") or summary.get("value") or summary.get("text") or "No description supplied by provider.",
            "road_name": location.get("description") or location.get("roadName") or "Road location not supplied",
            "shape": (location.get("shape") or {}).get("links", []),
        })
    return {
        "status": "ok", "provider": "HERE Traffic API v7", "queried_at": int(time.time()),
        "flow_source_updated": flow_data.get("sourceUpdated"),
        "incident_source_updated": incident_data.get("sourceUpdated"),
        "center": {"latitude": latitude, "longitude": longitude}, "radius_m": radius_m,
        "flow_count": len(flows), "incident_count": len(incidents), "flows": flows[:150], "incidents": incidents[:100],
        "disclaimer": "Road flow and incident data are provider observations for the selected search area and may change rapidly.",
    }


def traffic_provider_status() -> dict:
    return {"configured": bool(os.getenv("HERE_API_KEY", "").strip()), "provider": "HERE Maps Platform", "features": ["traffic-aware driving routes", "road flow congestion", "traffic incidents"]}
