"""Configurable GTFS Schedule and GTFS-Realtime integration.

No transit provider is bundled. Operators must publish GTFS data feeds.
"""
from __future__ import annotations
import csv, io, json, os, time, zipfile, heapq
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from backend.database import database_connection

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / 'config' / 'transit_feeds.json'
USER_AGENT = 'SmartJourneyPlanner-BinaryBrains/1.0 (academic project)'


def _schema(db_path):
    with database_connection(db_path) as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS transit_stops(stop_id TEXT PRIMARY KEY, stop_name TEXT NOT NULL, stop_lat REAL, stop_lon REAL, location_type INTEGER DEFAULT 0, parent_station TEXT);
        CREATE INDEX IF NOT EXISTS idx_transit_stops_name ON transit_stops(stop_name);
        CREATE TABLE IF NOT EXISTS transit_routes(route_id TEXT PRIMARY KEY, agency_id TEXT, short_name TEXT, long_name TEXT, route_type INTEGER, route_color TEXT);
        CREATE TABLE IF NOT EXISTS transit_trips(trip_id TEXT PRIMARY KEY, route_id TEXT NOT NULL, service_id TEXT, headsign TEXT, direction_id TEXT);
        CREATE INDEX IF NOT EXISTS idx_transit_trips_route ON transit_trips(route_id);
        CREATE TABLE IF NOT EXISTS transit_stop_times(trip_id TEXT NOT NULL, arrival_time TEXT, departure_time TEXT, stop_id TEXT NOT NULL, stop_sequence INTEGER NOT NULL, PRIMARY KEY(trip_id, stop_sequence));
        CREATE INDEX IF NOT EXISTS idx_transit_stop_times_stop ON transit_stop_times(stop_id);
        CREATE TABLE IF NOT EXISTS transit_calendar(service_id TEXT PRIMARY KEY, monday INTEGER,tuesday INTEGER,wednesday INTEGER,thursday INTEGER,friday INTEGER,saturday INTEGER,sunday INTEGER,start_date TEXT,end_date TEXT);
        CREATE TABLE IF NOT EXISTS transit_calendar_dates(service_id TEXT NOT NULL, service_date TEXT NOT NULL, exception_type INTEGER NOT NULL, PRIMARY KEY(service_id,service_date));
        CREATE TABLE IF NOT EXISTS transit_transfers(from_stop_id TEXT NOT NULL, to_stop_id TEXT NOT NULL, min_transfer_seconds INTEGER NOT NULL DEFAULT 300 CHECK(min_transfer_seconds>=0), transfer_type INTEGER NOT NULL DEFAULT 2, PRIMARY KEY(from_stop_id,to_stop_id));
        CREATE TABLE IF NOT EXISTS transit_feed_status(feed_name TEXT PRIMARY KEY, last_success REAL, last_error TEXT, vehicle_count INTEGER DEFAULT 0, alert_count INTEGER DEFAULT 0, trip_update_count INTEGER DEFAULT 0);
        ''')


def load_feed_config():
    try:
        from dotenv import load_dotenv
        load_dotenv(ROOT / '.env')
    except ImportError:
        pass
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError):
        raw = {'feeds': []}
    feeds = []
    for item in raw.get('feeds', []):
        name = str(item.get('name', 'Transit provider'))[:80]
        feeds.append({
            'name': name,
            'vehicle_url': os.getenv(item.get('vehicle_url_env', ''), item.get('vehicle_url', '')) if item.get('vehicle_url_env') else item.get('vehicle_url', ''),
            'trip_update_url': os.getenv(item.get('trip_update_url_env', ''), item.get('trip_update_url', '')) if item.get('trip_update_url_env') else item.get('trip_update_url', ''),
            'alert_url': os.getenv(item.get('alert_url_env', ''), item.get('alert_url', '')) if item.get('alert_url_env') else item.get('alert_url', ''),
            'schedule_url': item.get('schedule_url', ''),
            'headers_env': item.get('headers_env', {})
        })
    return feeds


def _fetch(url, headers=None, timeout=12):
    if not url or not str(url).startswith('https://'):
        raise ValueError('Feed URL must be configured as an HTTPS URL.')
    req = Request(url, headers={'User-Agent': USER_AGENT, **(headers or {})})
    with urlopen(req, timeout=timeout) as response:
        return response.read()


def _prefixed(value, prefix):
    return f'{prefix}:{value}' if prefix and value else value


def _parse_realtime(payload, id_prefix=''):
    try:
        from google.transit import gtfs_realtime_pb2
    except ImportError as exc:
        raise RuntimeError('GTFS Realtime parser is not installed. Run run_windows.bat to install requirements.') from exc
    feed = gtfs_realtime_pb2.FeedMessage()
    feed.ParseFromString(payload)
    vehicles, alerts, updates = [], [], []
    for entity in feed.entity:
        if entity.HasField('vehicle'):
            v = entity.vehicle
            if v.HasField('position'):
                vehicles.append({'id': v.vehicle.id or entity.id, 'label': v.vehicle.label,
                    'trip_id': _prefixed(v.trip.trip_id, id_prefix), 'route_id': _prefixed(v.trip.route_id, id_prefix),
                    'latitude': v.position.latitude, 'longitude': v.position.longitude,
                    'bearing': v.position.bearing if v.position.HasField('bearing') else None,
                    'speed_mps': v.position.speed if v.position.HasField('speed') else None,
                    'timestamp': v.timestamp if v.HasField('timestamp') else None})
        if entity.HasField('trip_update'):
            tu = entity.trip_update
            trip_status = str(tu.trip.schedule_relationship) if tu.trip.HasField('schedule_relationship') else '0'
            if not tu.stop_time_update:
                updates.append({'trip_id': _prefixed(tu.trip.trip_id, id_prefix), 'stop_id': '',
                    'trip_status': trip_status, 'stop_sequence': None, 'arrival_delay': None,
                    'departure_delay': None, 'schedule_relationship': '0'})
            for stu in tu.stop_time_update:
                updates.append({'trip_id': _prefixed(tu.trip.trip_id, id_prefix), 'stop_id': _prefixed(stu.stop_id, id_prefix),
                    'trip_status': trip_status,
                    'stop_sequence': stu.stop_sequence if stu.HasField('stop_sequence') else None,
                    'arrival_delay': stu.arrival.delay if stu.HasField('arrival') and stu.arrival.HasField('delay') else None,
                    'departure_delay': stu.departure.delay if stu.HasField('departure') and stu.departure.HasField('delay') else None,
                    'schedule_relationship': str(stu.schedule_relationship)})
        if entity.HasField('alert'):
            alert = entity.alert
            def translated(value):
                return next((t.text for t in value.translation if t.text), '') if value.translation else ''
            alerts.append({'id': entity.id, 'header': translated(alert.header_text),
                'description': translated(alert.description_text),
                'url': translated(alert.url), 'cause': {1:'Unknown',2:'Other',3:'Technical problem',4:'Strike',5:'Demonstration',6:'Accident',7:'Holiday',8:'Weather',9:'Maintenance',10:'Construction',11:'Police activity',12:'Medical emergency'}.get(int(alert.cause),'Unknown'),
                'effect': {1:'No service',2:'Reduced service',3:'Significant delays',4:'Detour',5:'Additional service',6:'Modified service',7:'Other effect',8:'Unknown effect',9:'Stop moved',10:'No effect',11:'Accessibility issue'}.get(int(alert.effect),'Unknown'), 'active_periods': [
                    {'start': p.start if p.HasField('start') else None, 'end': p.end if p.HasField('end') else None}
                    for p in alert.active_period]})
    return {'vehicles': vehicles, 'alerts': alerts, 'trip_updates': updates,
            'feed_timestamp': feed.header.timestamp if feed.header.HasField('timestamp') else None}


def fetch_live(db_path):
    _schema(db_path)
    feeds = load_feed_config()
    aggregate = {'configured': 0, 'providers': [], 'vehicles': [], 'alerts': [], 'trip_updates': [], 'fetched_at': int(time.time())}
    for cfg in feeds:
        if any(cfg.get(k) for k in ('vehicle_url','trip_update_url','alert_url')):
            aggregate['configured'] += 1
        result = {'name': cfg['name'], 'status': 'not_configured', 'freshness': 'unknown', 'vehicle_count': 0, 'alert_count': 0, 'trip_update_count': 0, 'errors': []}
        headers = {}
        for header_name, env_name in cfg.get('headers_env', {}).items():
            if os.getenv(env_name): headers[header_name] = os.environ[env_name]
        for kind, key in [('vehicle_url','vehicles'), ('trip_update_url','trip_updates'), ('alert_url','alerts')]:
            url = cfg.get(kind)
            if not url: continue
            try:
                parsed = _parse_realtime(_fetch(url, headers), cfg.get('id_prefix', ''))
                age = max(0, int(time.time() - parsed['feed_timestamp'])) if parsed.get('feed_timestamp') else None
                threshold = 600 if key == 'alerts' else 90
                freshness = 'unknown' if age is None else ('stale' if age > threshold else 'fresh')
                result.setdefault('feed_freshness', {})[key] = {'age_seconds': age, 'state': freshness}
                aggregate[key].extend([{**x, 'provider': cfg['name'], 'feed_age_seconds': age, 'freshness': freshness} for x in parsed[key]])
                result['vehicle_count'] += len(parsed['vehicles'])
                result['alert_count'] += len(parsed['alerts'])
                result['trip_update_count'] += len(parsed['trip_updates'])
                result['status'] = 'live'
                if freshness == 'stale': result['freshness'] = 'stale'
                elif freshness == 'fresh' and result['freshness'] != 'stale': result['freshness'] = 'fresh'
            except Exception as exc:
                result['errors'].append(f'{kind}: {str(exc)[:240]}')
        if result['status'] == 'not_configured' and result['errors']:
            result['status'] = 'error'
        with database_connection(db_path) as con:
            con.execute('''INSERT INTO transit_feed_status(feed_name,last_success,last_error,vehicle_count,alert_count,trip_update_count)
                VALUES(?,?,?,?,?,?) ON CONFLICT(feed_name) DO UPDATE SET last_success=excluded.last_success,last_error=excluded.last_error,vehicle_count=excluded.vehicle_count,alert_count=excluded.alert_count,trip_update_count=excluded.trip_update_count''',
                (cfg['name'], time.time() if result['status']=='live' else None, '; '.join(result['errors']), result['vehicle_count'], result['alert_count'], result['trip_update_count']))
        aggregate['providers'].append(result)
    return aggregate


def import_gtfs_zip(file_bytes: bytes, db_path, prefix='', merge=False):
    _schema(db_path)
    required = {'stops.txt','routes.txt','trips.txt','stop_times.txt'}
    try:
        archive = zipfile.ZipFile(io.BytesIO(file_bytes))
    except zipfile.BadZipFile as exc:
        raise ValueError('Upload a valid GTFS ZIP file.') from exc
    names = {Path(n).name for n in archive.namelist()}
    missing = required - names
    if missing: raise ValueError('GTFS ZIP is missing: ' + ', '.join(sorted(missing)))
    def rows(filename):
        member = next(n for n in archive.namelist() if Path(n).name == filename)
        with archive.open(member) as raw:
            wrapper = io.TextIOWrapper(raw, encoding='utf-8-sig', newline='')
            return list(csv.DictReader(wrapper))
    stops, routes, trips, times = (rows(x) for x in ['stops.txt','routes.txt','trips.txt','stop_times.txt'])
    calendar = rows('calendar.txt') if 'calendar.txt' in names else []
    dates = rows('calendar_dates.txt') if 'calendar_dates.txt' in names else []
    transfers = rows('transfers.txt') if 'transfers.txt' in names else []
    if not stops or not routes or not trips or not times: raise ValueError('GTFS required files must contain data.')
    if not calendar and not dates: raise ValueError('GTFS must include calendar.txt or calendar_dates.txt to determine active service days.')
    prefix = ''.join(ch for ch in str(prefix).strip().lower() if ch.isalnum() or ch in '_-')[:32]
    if merge and not prefix:
        raise ValueError('Enter a short operator prefix when adding another feed.')
    with database_connection(db_path) as connection:
        if not merge:
            for table in ('transit_stop_times','transit_trips','transit_routes','transit_stops','transit_calendar','transit_calendar_dates','transit_transfers'):
                connection.execute(f'DELETE FROM {table}')
        connection.executemany('INSERT OR REPLACE INTO transit_stops VALUES(?,?,?,?,?,?)', [
            (_prefixed(r['stop_id'],prefix),r.get('stop_name',''),_float(r.get('stop_lat')),_float(r.get('stop_lon')),
             _int(r.get('location_type')) or 0,_prefixed(r.get('parent_station'),prefix)) for r in stops])
        connection.executemany('INSERT OR REPLACE INTO transit_routes VALUES(?,?,?,?,?,?)', [
            (_prefixed(r['route_id'],prefix),_prefixed(r.get('agency_id'),prefix),r.get('route_short_name'),
             r.get('route_long_name'),_int(r.get('route_type')),_clean_color(r.get('route_color'))) for r in routes])
        connection.executemany('INSERT OR REPLACE INTO transit_trips VALUES(?,?,?,?,?)', [
            (_prefixed(r['trip_id'],prefix),_prefixed(r['route_id'],prefix),_prefixed(r.get('service_id'),prefix),
             r.get('trip_headsign'),r.get('direction_id')) for r in trips])
        connection.executemany('INSERT OR REPLACE INTO transit_stop_times VALUES(?,?,?,?,?)', [
            (_prefixed(r['trip_id'],prefix),r.get('arrival_time'),r.get('departure_time'),
             _prefixed(r['stop_id'],prefix),int(r['stop_sequence'])) for r in times])
        if calendar:
            connection.executemany('INSERT OR REPLACE INTO transit_calendar VALUES(?,?,?,?,?,?,?,?,?,?)', [
                (_prefixed(r['service_id'],prefix),*[int(r.get(d,0) or 0) for d in
                 ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']],
                 r.get('start_date'),r.get('end_date')) for r in calendar])
        if dates:
            connection.executemany('INSERT OR REPLACE INTO transit_calendar_dates VALUES(?,?,?)', [
                (_prefixed(r['service_id'],prefix),r['date'],int(r['exception_type'])) for r in dates])
        if transfers:
            connection.executemany('INSERT OR REPLACE INTO transit_transfers VALUES(?,?,?,?)', [
                (_prefixed(r['from_stop_id'],prefix),_prefixed(r['to_stop_id'],prefix),
                 int(r.get('min_transfer_time') or 300),int(r.get('transfer_type') or 0)) for r in transfers
                 if int(r.get('transfer_type') or 0) not in (3,)])
    return {'stops':len(stops),'routes':len(routes),'trips':len(trips),'stop_times':len(times),'calendar_services':len(calendar),'calendar_exceptions':len(dates),'transfers':len(transfers),'prefix':prefix or None,'merged':bool(merge)}


def _float(v):
    try: return float(v) if v not in (None,'') else None
    except ValueError: return None

def _int(v):
    try: return int(v) if v not in (None,'') else None
    except ValueError: return None

def _clean_color(v):
    v=(v or '').strip().lstrip('#')
    return v if len(v)==6 and all(c in '0123456789abcdefABCDEF' for c in v) else None


def search_stops(query, db_path, limit=12):
    with database_connection(db_path) as con:
        rows=con.execute('SELECT stop_id,stop_name,stop_lat,stop_lon FROM transit_stops WHERE stop_name LIKE ? ORDER BY stop_name LIMIT ?',('%'+query+'%',limit)).fetchall()
        return [dict(r) for r in rows]


def next_departures(stop_id, db_path, limit=20):
    now=datetime.now(); day=now.strftime('%Y%m%d'); weekday=now.weekday()
    day_col=['monday','tuesday','wednesday','thursday','friday','saturday','sunday'][weekday]
    hhmmss=now.strftime('%H:%M:%S')
    with database_connection(db_path) as con:
        rows=con.execute(f'''SELECT st.trip_id,st.departure_time,st.stop_sequence,s.stop_name,r.route_id,r.short_name,r.long_name,t.headsign,t.service_id
            FROM transit_stop_times st JOIN transit_stops s ON s.stop_id=st.stop_id JOIN transit_trips t ON t.trip_id=st.trip_id JOIN transit_routes r ON r.route_id=t.route_id
            WHERE st.stop_id=? AND st.departure_time>=? AND (
             EXISTS(SELECT 1 FROM transit_calendar c WHERE c.service_id=t.service_id AND c.{day_col}=1 AND c.start_date<=? AND c.end_date>=?)
             OR EXISTS(SELECT 1 FROM transit_calendar_dates cd WHERE cd.service_id=t.service_id AND cd.service_date=? AND cd.exception_type=1))
             AND NOT EXISTS(SELECT 1 FROM transit_calendar_dates cd WHERE cd.service_id=t.service_id AND cd.service_date=? AND cd.exception_type=2)
            ORDER BY st.departure_time LIMIT ?''',(stop_id,hhmmss,day,day,day,day,limit)).fetchall()
        return [dict(r) for r in rows]


def transit_summary(db_path):
    _schema(db_path)
    with database_connection(db_path) as con:
        return {'stops':con.execute('SELECT COUNT(*) FROM transit_stops').fetchone()[0], 'routes':con.execute('SELECT COUNT(*) FROM transit_routes').fetchone()[0], 'trips':con.execute('SELECT COUNT(*) FROM transit_trips').fetchone()[0], 'transfers':con.execute("SELECT COUNT(DISTINCT CASE WHEN from_stop_id<to_stop_id THEN from_stop_id||'|'||to_stop_id ELSE to_stop_id||'|'||from_stop_id END) FROM transit_transfers").fetchone()[0], 'providers_configured':sum(1 for cfg in load_feed_config() if any(cfg.get(k) for k in ('vehicle_url','trip_update_url','alert_url'))) }


def _gtfs_seconds(value):
    try:
        h,m,s=map(int,value.split(':')); return h*3600+m*60+s
    except Exception: return None


def add_transit_transfer(from_stop_id, to_stop_id, minutes, db_path):
    if from_stop_id == to_stop_id:
        raise ValueError('Choose two different stops for a walking transfer.')
    seconds = int(float(minutes) * 60)
    if seconds < 60 or seconds > 7200:
        raise ValueError('Walking transfer must be between 1 and 120 minutes.')
    with database_connection(db_path) as con:
        for stop_id in (from_stop_id, to_stop_id):
            if not con.execute('SELECT 1 FROM transit_stops WHERE stop_id=?',(stop_id,)).fetchone():
                raise ValueError('Both stops must exist in an imported GTFS schedule.')
        con.execute('INSERT OR REPLACE INTO transit_transfers VALUES(?,?,?,2)',(from_stop_id,to_stop_id,seconds))
        con.execute('INSERT OR REPLACE INTO transit_transfers VALUES(?,?,?,2)',(to_stop_id,from_stop_id,seconds))
    return {'from_stop_id':from_stop_id,'to_stop_id':to_stop_id,'walking_minutes':seconds/60,'bidirectional':True}


def list_transit_transfers(db_path):
    with database_connection(db_path) as con:
        rows=con.execute('SELECT x.from_stop_id,x.to_stop_id,x.min_transfer_seconds,a.stop_name AS from_name,b.stop_name AS to_name FROM transit_transfers x JOIN transit_stops a ON a.stop_id=x.from_stop_id JOIN transit_stops b ON b.stop_id=x.to_stop_id ORDER BY a.stop_name,b.stop_name').fetchall()
        return [dict(r) for r in rows]


def plan_transit(origin_stop_id, destination_stop_id, db_path, max_transfers=3):
    """Find an earliest-arrival GTFS journey with up to max_transfers changes."""
    if origin_stop_id == destination_stop_id:
        raise ValueError('Choose two different stops.')
    now = datetime.now()
    day = now.strftime('%Y%m%d')
    weekday = now.weekday()
    day_col = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'][weekday]
    with database_connection(db_path) as con:
        active = {r['service_id'] for r in con.execute(
            f"SELECT service_id FROM transit_calendar WHERE {day_col}=1 AND start_date<=? AND end_date>=?", (day, day))}
        for row in con.execute('SELECT service_id,exception_type FROM transit_calendar_dates WHERE service_date=?', (day,)):
            if row['exception_type'] == 1:
                active.add(row['service_id'])
            elif row['exception_type'] == 2:
                active.discard(row['service_id'])
        if not active:
            return {'status':'unavailable','message':'No active GTFS service calendar was found for today. Import a current GTFS schedule.'}
        placeholders = ','.join('?' for _ in active)
        rows = con.execute(f"""SELECT chain.trip_id,chain.from_id,chain.dep,chain.to_id,chain.arr,
            t.route_id,r.short_name,r.long_name,r.route_type,t.headsign
            FROM (SELECT trip_id,stop_id AS from_id,departure_time AS dep,
                  LEAD(stop_id) OVER (PARTITION BY trip_id ORDER BY stop_sequence) AS to_id,
                  LEAD(arrival_time) OVER (PARTITION BY trip_id ORDER BY stop_sequence) AS arr
                  FROM transit_stop_times) chain
            JOIN transit_trips t ON t.trip_id=chain.trip_id
            JOIN transit_routes r ON r.route_id=t.route_id
            WHERE t.service_id IN ({placeholders}) AND chain.to_id IS NOT NULL
            ORDER BY chain.dep""", tuple(active)).fetchall()
        stops = {r['stop_id']:dict(r) for r in con.execute('SELECT stop_id,stop_name,stop_lat,stop_lon FROM transit_stops')}
    if origin_stop_id not in stops or destination_stop_id not in stops:
        raise ValueError('Origin or destination stop was not found in the imported GTFS schedule.')
    outgoing = {}
    for row in rows:
        dep, arr = _gtfs_seconds(row['dep']), _gtfs_seconds(row['arr'])
        if dep is None or arr is None or arr < dep:
            continue
        item = {**dict(row), 'dep_s':dep, 'arr_s':arr}
        outgoing.setdefault(item['from_id'], []).append(item)
    with database_connection(db_path) as con:
        walking_rows = con.execute('SELECT from_stop_id,to_stop_id,min_transfer_seconds FROM transit_transfers').fetchall()
    for row in walking_rows:
        if row['from_stop_id'] not in stops or row['to_stop_id'] not in stops:
            continue
        outgoing.setdefault(row['from_stop_id'], []).append({'trip_id':'__WALK__','from_id':row['from_stop_id'],
            'to_id':row['to_stop_id'],'dep':'','arr':'','dep_s':0,'arr_s':int(row['min_transfer_seconds']),
            'route_id':'WALK','short_name':'Walk transfer','long_name':'Walking connection','route_type':99,
            'headsign':stops[row['to_stop_id']]['stop_name'],'mode':'Walk','walk_seconds':int(row['min_transfer_seconds'])})
    start = now.hour*3600 + now.minute*60 + now.second
    initial = (origin_stop_id, '', 0)
    distances = {initial:start}
    previous = {}
    queue = [(start, origin_stop_id, '', 0)]
    final_state = None
    while queue:
        arrival, stop_id, last_trip, transfers = heapq.heappop(queue)
        state = (stop_id, last_trip, transfers)
        if arrival != distances.get(state):
            continue
        if stop_id == destination_stop_id:
            final_state = state
            break
        for edge in outgoing.get(stop_id, []):
            is_walk = edge.get('mode') == 'Walk'
            if is_walk:
                new_transfers, next_trip = transfers, last_trip
                dep_s, arr_s = arrival, arrival + edge['walk_seconds']
            else:
                same_trip = last_trip == edge['trip_id']
                new_transfers = transfers if (not last_trip or same_trip) else transfers + 1
                if new_transfers > max_transfers:
                    continue
                ready = arrival if (not last_trip or same_trip) else arrival + 300
                if edge['dep_s'] < ready:
                    continue
                next_trip, dep_s, arr_s = edge['trip_id'], edge['dep_s'], edge['arr_s']
            next_state = (edge['to_id'], next_trip, new_transfers)
            if arr_s < distances.get(next_state, 10**12):
                distances[next_state] = arr_s
                previous[next_state] = (state, {**edge, 'dep_s':dep_s, 'arr_s':arr_s})
                heapq.heappush(queue, (arr_s, edge['to_id'], next_trip, new_transfers))
    if final_state is None:
        return {'status':'unavailable','message':'No scheduled journey was found with up to three transfers.'}
    path = []
    cursor = final_state
    while cursor != initial and cursor in previous:
        prev, edge = previous[cursor]
        path.append(edge)
        cursor = prev
    path.reverse()
    legs = []
    for edge in path:
        if edge.get('mode') == 'Walk':
            def clock(value):
                return f'{(value//3600)%24:02d}:{(value%3600)//60:02d}:{value%60:02d}'
            legs.append({'trip_id':'__WALK__','route_id':'WALK','route_name':'Walking transfer','mode':'Walk',
                'headsign':'Walk to the next stop','from_stop':stops[edge['from_id']]['stop_name'],
                'from_stop_id':edge['from_id'],'to_stop':stops[edge['to_id']]['stop_name'],'to_stop_id':edge['to_id'],
                'departure':clock(edge['dep_s']),'arrival':clock(edge['arr_s']),
                'from_lat':stops[edge['from_id']]['stop_lat'],'from_lon':stops[edge['from_id']]['stop_lon'],
                'to_lat':stops[edge['to_id']]['stop_lat'],'to_lon':stops[edge['to_id']]['stop_lon']})
            continue
        if legs and legs[-1]['trip_id'] == edge['trip_id']:
            legs[-1]['to_stop'] = stops[edge['to_id']]['stop_name']
            legs[-1]['to_stop_id'] = edge['to_id']
            legs[-1]['arrival'] = edge['arr']
            legs[-1]['to_lat'] = stops[edge['to_id']]['stop_lat']
            legs[-1]['to_lon'] = stops[edge['to_id']]['stop_lon']
        else:
            legs.append({'trip_id':edge['trip_id'],'route_id':edge['route_id'],
                'route_name':edge['short_name'] or edge['long_name'] or edge['route_id'],
                'mode':{0:'Tram',1:'Metro',2:'Rail',3:'Bus',4:'Ferry',5:'Cable tram',6:'Gondola',7:'Funicular'}.get(edge['route_type'],'Transit'),
                'headsign':edge['headsign'],'from_stop':stops[edge['from_id']]['stop_name'],
                'from_stop_id':edge['from_id'],'to_stop':stops[edge['to_id']]['stop_name'],
                'to_stop_id':edge['to_id'],'departure':edge['dep'],'arrival':edge['arr'],
                'from_lat':stops[edge['from_id']]['stop_lat'],'from_lon':stops[edge['from_id']]['stop_lon'],
                'to_lat':stops[edge['to_id']]['stop_lat'],'to_lon':stops[edge['to_id']]['stop_lon']})
    return {'status':'ok','origin':stops[origin_stop_id]['stop_name'],
        'destination':stops[destination_stop_id]['stop_name'],'legs':legs,
        'transfers':max(0,sum(1 for leg in legs if leg.get('mode') != 'Walk')-1),'departure':legs[0]['departure'],
        'arrival':legs[-1]['arrival'],'data_type':'scheduled_gtfs',
        'disclaimer':'Timetable-based itinerary. Realtime delays and cancellations may change this journey.'}
