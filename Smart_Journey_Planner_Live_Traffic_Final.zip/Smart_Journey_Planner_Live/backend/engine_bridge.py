"""Safe adapter that converts SQLite records into input for the existing C CLI."""
from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path

from backend.database import get_connection

ROOT = Path(__file__).resolve().parent.parent


class EngineError(RuntimeError):
    pass


def find_engine() -> Path:
    configured = os.environ.get("JOURNEY_ENGINE_PATH")
    candidates = [Path(configured)] if configured else []
    candidates += [ROOT / "journey_engine.exe", ROOT / "journey_engine"]
    for candidate in candidates:
        if candidate and candidate.is_file():
            return candidate.resolve()
    raise EngineError("C engine not found. Run build_windows.bat (Windows) or make (Linux/macOS) first.")


def export_database_graph(db_path: str | Path) -> str:
    """Write a temporary Stage 3-compatible graph file using database IDs."""
    with get_connection(db_path) as connection:
        cities = connection.execute("SELECT id, name FROM cities ORDER BY id").fetchall()
        routes = connection.execute(
            "SELECT source_city_id, destination_city_id, distance_km, duration_min, fare_rupees, transport_mode FROM routes ORDER BY id"
        ).fetchall()
    if not cities:
        raise EngineError("The database has no cities. Add at least one city first.")
    index_by_id = {row["id"]: index for index, row in enumerate(cities)}
    lines = [f"CITY|{row['name']}" for row in cities]
    for route in routes:
        lines.append(
            "EDGE|{}|{}|{}|{}|{}|{}".format(
                index_by_id[route["source_city_id"]], index_by_id[route["destination_city_id"]],
                route["distance_km"], route["duration_min"], route["fare_rupees"], route["transport_mode"]
            )
        )
    handle = tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".txt", delete=False)
    try:
        handle.write("\n".join(lines) + "\n")
        return handle.name
    finally:
        handle.close()


def run_engine(db_path: str | Path, command: str, source: str, destination: str | None = None,
               metric: str | None = None) -> dict:
    executable = find_engine()
    data_file = export_database_graph(db_path)
    try:
        args = [str(executable), "--data", data_file]
        if command == "route":
            args += ["route", source, destination or "", metric or "distance"]
        elif command == "bfs":
            args += ["bfs", source, destination or ""]
        elif command == "dfs":
            args += ["dfs", source]
        else:
            raise EngineError("Unsupported C engine command.")
        completed = subprocess.run(args, capture_output=True, text=True, timeout=10, check=False)
        output = completed.stdout.strip()
        if not output:
            detail = completed.stderr.strip() or "The C engine returned no output."
            raise EngineError(detail)
        try:
            payload = json.loads(output)
        except json.JSONDecodeError as exc:
            raise EngineError("The C engine returned invalid JSON.") from exc
        if completed.returncode not in (0, 2) and payload.get("status") == "error":
            raise EngineError(payload.get("message", "C engine calculation failed."))
        return payload
    except subprocess.TimeoutExpired as exc:
        raise EngineError("The C engine took too long to respond.") from exc
    finally:
        try:
            os.unlink(data_file)
        except OSError:
            pass
