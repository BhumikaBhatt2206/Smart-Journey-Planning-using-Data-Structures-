#include "graph.h"
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned long hash_name(const char *text) {
    unsigned long hash = 5381UL;
    int ch;
    while ((ch = (unsigned char)*text++) != 0) {
        hash = ((hash << 5) + hash) + (unsigned long)tolower(ch);
    }
    return hash;
}

static int names_equal(const char *a, const char *b) {
    while (*a && *b) {
        if (tolower((unsigned char)*a) != tolower((unsigned char)*b)) return 0;
        ++a; ++b;
    }
    return *a == '\0' && *b == '\0';
}

static int rebuild_hash(Graph *graph, size_t requested_capacity) {
    size_t capacity = 16;
    while (capacity < requested_capacity) capacity *= 2;
    int *slots = (int *)malloc(capacity * sizeof(int));
    if (!slots) return 0;
    for (size_t i = 0; i < capacity; ++i) slots[i] = -1;
    for (size_t id = 0; id < graph->city_count; ++id) {
        size_t index = (size_t)(hash_name(graph->cities[id].name) & (capacity - 1));
        while (slots[index] != -1) index = (index + 1) & (capacity - 1);
        slots[index] = (int)id;
    }
    free(graph->hash_slots);
    graph->hash_slots = slots;
    graph->hash_capacity = capacity;
    return 1;
}

int graph_init(Graph *graph, size_t initial_capacity) {
    if (!graph) return 0;
    memset(graph, 0, sizeof(*graph));
    graph->city_capacity = initial_capacity ? initial_capacity : 8;
    graph->cities = (City *)calloc(graph->city_capacity, sizeof(City));
    if (!graph->cities) return 0;
    if (!rebuild_hash(graph, graph->city_capacity * 2)) {
        free(graph->cities);
        memset(graph, 0, sizeof(*graph));
        return 0;
    }
    return 1;
}

void graph_free(Graph *graph) {
    if (!graph) return;
    for (size_t i = 0; i < graph->city_count; ++i) {
        Edge *edge = graph->cities[i].head;
        while (edge) {
            Edge *next = edge->next;
            free(edge);
            edge = next;
        }
    }
    free(graph->cities);
    free(graph->hash_slots);
    memset(graph, 0, sizeof(*graph));
}

int graph_find_city(const Graph *graph, const char *name) {
    if (!graph || !name || !graph->hash_slots || graph->hash_capacity == 0) return -1;
    size_t index = (size_t)(hash_name(name) & (graph->hash_capacity - 1));
    size_t start = index;
    while (graph->hash_slots[index] != -1) {
        int id = graph->hash_slots[index];
        if (names_equal(graph->cities[id].name, name)) return id;
        index = (index + 1) & (graph->hash_capacity - 1);
        if (index == start) break;
    }
    return -1;
}

int graph_add_city(Graph *graph, const char *name) {
    if (!graph || !name || name[0] == '\0' || strlen(name) >= CITY_NAME_MAX) return -1;
    if (graph_find_city(graph, name) != -1) return -1;
    if ((graph->city_count + 1) * 10 >= graph->hash_capacity * 7) {
        if (!rebuild_hash(graph, graph->hash_capacity * 2)) return -1;
    }
    if (graph->city_count == graph->city_capacity) {
        size_t new_capacity = graph->city_capacity * 2;
        City *grown = (City *)realloc(graph->cities, new_capacity * sizeof(City));
        if (!grown) return -1;
        memset(grown + graph->city_capacity, 0, (new_capacity - graph->city_capacity) * sizeof(City));
        graph->cities = grown;
        graph->city_capacity = new_capacity;
    }
    size_t id = graph->city_count;
    snprintf(graph->cities[id].name, sizeof(graph->cities[id].name), "%s", name);
    graph->cities[id].head = NULL;
    graph->city_count++;
    /* Rebuild so the new city is indexed and the table remains simple and safe. */
    if (!rebuild_hash(graph, graph->hash_capacity)) {
        graph->city_count--;
        return -1;
    }
    return (int)id;
}

int graph_add_route_one_way(Graph *graph, int from, int to, double distance_km,
                            double duration_min, double fare_rupees, const char *mode) {
    if (!graph || from < 0 || to < 0 || (size_t)from >= graph->city_count ||
        (size_t)to >= graph->city_count || from == to || !mode || mode[0] == '\0' ||
        strlen(mode) >= TRANSPORT_MODE_MAX || !isfinite(distance_km) ||
        !isfinite(duration_min) || !isfinite(fare_rupees) || distance_km < 0 ||
        duration_min < 0 || fare_rupees < 0) return 0;
    for (Edge *existing = graph->cities[from].head; existing; existing = existing->next) {
        if (existing->to == to && strcmp(existing->mode, mode) == 0 &&
            existing->distance_km == distance_km &&
            existing->duration_min == duration_min &&
            existing->fare_rupees == fare_rupees) {
            return 0; /* Reject an exact duplicate connection. */
        }
    }
    Edge *edge = (Edge *)malloc(sizeof(Edge));
    if (!edge) return 0;
    edge->to = to;
    edge->distance_km = distance_km;
    edge->duration_min = duration_min;
    edge->fare_rupees = fare_rupees;
    snprintf(edge->mode, sizeof(edge->mode), "%s", mode);
    edge->next = graph->cities[from].head;
    graph->cities[from].head = edge;
    graph->directed_edge_count++;
    return 1;
}

int graph_add_route(Graph *graph, int from, int to, double distance_km,
                    double duration_min, double fare_rupees, const char *mode) {
    if (!graph || from < 0 || to < 0 || (size_t)from >= graph->city_count ||
        (size_t)to >= graph->city_count || from == to || !mode || mode[0] == '\0' ||
        strlen(mode) >= TRANSPORT_MODE_MAX || !isfinite(distance_km) ||
        !isfinite(duration_min) || !isfinite(fare_rupees) || distance_km < 0 ||
        duration_min < 0 || fare_rupees < 0) return 0;
    if (!graph_add_route_one_way(graph, from, to, distance_km, duration_min, fare_rupees, mode))
        return 0;
    if (!graph_add_route_one_way(graph, to, from, distance_km, duration_min, fare_rupees, mode)) {
        /* Roll back the first direction if the second allocation fails. */
        Edge **cursor = &graph->cities[from].head;
        while (*cursor && !((*cursor)->to == to && strcmp((*cursor)->mode, mode) == 0))
            cursor = &(*cursor)->next;
        if (*cursor) {
            Edge *removed = *cursor;
            *cursor = removed->next;
            free(removed);
            graph->directed_edge_count--;
        }
        return 0;
    }
    return 1;
}

void graph_print_cities(const Graph *graph) {
    if (!graph) return;
    puts("\nAvailable cities:");
    for (size_t i = 0; i < graph->city_count; ++i)
        printf("  %zu. %s\n", i + 1, graph->cities[i].name);
}

void graph_print_routes(const Graph *graph) {
    if (!graph) return;
    puts("\nSample connections (illustrative estimates):");
    for (size_t from = 0; from < graph->city_count; ++from) {
        for (Edge *edge = graph->cities[from].head; edge; edge = edge->next) {
            if ((int)from < edge->to)
                printf("  %-12s <-> %-12s | %.1f km | %.0f min | Rs %.0f | %s\n",
                       graph->cities[from].name, graph->cities[edge->to].name,
                       edge->distance_km, edge->duration_min, edge->fare_rupees, edge->mode);
        }
    }
}
