#ifndef GRAPH_H
#define GRAPH_H

#include <stddef.h>

#define CITY_NAME_MAX 100
#define TRANSPORT_MODE_MAX 24

typedef struct Edge {
    int to;
    double distance_km;
    double duration_min;
    double fare_rupees;
    char mode[TRANSPORT_MODE_MAX];
    struct Edge *next;
} Edge;

typedef struct {
    char name[CITY_NAME_MAX];
    Edge *head;
} City;

typedef struct {
    City *cities;
    size_t city_count;
    size_t city_capacity;
    int *hash_slots;
    size_t hash_capacity;
    size_t directed_edge_count;
} Graph;

int graph_init(Graph *graph, size_t initial_capacity);
void graph_free(Graph *graph);
int graph_add_city(Graph *graph, const char *name);
int graph_find_city(const Graph *graph, const char *name);
int graph_add_route(Graph *graph, int from, int to, double distance_km,
                    double duration_min, double fare_rupees, const char *mode);
int graph_add_route_one_way(Graph *graph, int from, int to, double distance_km,
                            double duration_min, double fare_rupees, const char *mode);
void graph_print_cities(const Graph *graph);
void graph_print_routes(const Graph *graph);

#endif
