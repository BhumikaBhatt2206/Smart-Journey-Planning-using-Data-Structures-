#include "min_heap.h"
#include <stdlib.h>

static void swap_nodes(HeapNode *a, HeapNode *b) {
    HeapNode temp = *a;
    *a = *b;
    *b = temp;
}

int heap_init(MinHeap *heap, size_t initial_capacity) {
    if (!heap) return 0;
    heap->items = NULL;
    heap->size = 0;
    heap->capacity = initial_capacity ? initial_capacity : 16;
    heap->items = (HeapNode *)malloc(heap->capacity * sizeof(HeapNode));
    return heap->items != NULL;
}

void heap_free(MinHeap *heap) {
    if (!heap) return;
    free(heap->items);
    heap->items = NULL;
    heap->size = heap->capacity = 0;
}

int heap_push(MinHeap *heap, int vertex, double priority) {
    if (!heap || !heap->items) return 0;
    if (heap->size == heap->capacity) {
        size_t new_capacity = heap->capacity * 2;
        HeapNode *grown = (HeapNode *)realloc(heap->items, new_capacity * sizeof(HeapNode));
        if (!grown) return 0;
        heap->items = grown;
        heap->capacity = new_capacity;
    }
    size_t i = heap->size++;
    heap->items[i].vertex = vertex;
    heap->items[i].priority = priority;
    while (i > 0) {
        size_t parent = (i - 1) / 2;
        if (heap->items[parent].priority <= heap->items[i].priority) break;
        swap_nodes(&heap->items[parent], &heap->items[i]);
        i = parent;
    }
    return 1;
}

int heap_pop(MinHeap *heap, HeapNode *result) {
    if (!heap || !result || heap->size == 0) return 0;
    *result = heap->items[0];
    heap->size--;
    if (heap->size == 0) return 1;
    heap->items[0] = heap->items[heap->size];
    size_t i = 0;
    for (;;) {
        size_t left = 2 * i + 1, right = 2 * i + 2, smallest = i;
        if (left < heap->size && heap->items[left].priority < heap->items[smallest].priority)
            smallest = left;
        if (right < heap->size && heap->items[right].priority < heap->items[smallest].priority)
            smallest = right;
        if (smallest == i) break;
        swap_nodes(&heap->items[i], &heap->items[smallest]);
        i = smallest;
    }
    return 1;
}
