#ifndef MIN_HEAP_H
#define MIN_HEAP_H

#include <stddef.h>

typedef struct {
    int vertex;
    double priority;
} HeapNode;

typedef struct {
    HeapNode *items;
    size_t size;
    size_t capacity;
} MinHeap;

int heap_init(MinHeap *heap, size_t initial_capacity);
void heap_free(MinHeap *heap);
int heap_push(MinHeap *heap, int vertex, double priority);
int heap_pop(MinHeap *heap, HeapNode *result);

#endif
