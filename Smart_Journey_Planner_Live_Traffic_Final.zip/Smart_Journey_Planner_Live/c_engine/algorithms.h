#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include "graph.h"

typedef enum {
    METRIC_DISTANCE = 1,
    METRIC_TIME = 2,
    METRIC_FARE = 3,
    METRIC_CONNECTIONS = 4
} RouteMetric;

typedef struct {
    int found;
    int *city_ids;
    size_t path_length;
    double total_distance_km;
    double total_duration_min;
    double total_fare_rupees;
    double optimized_weight;
} RouteResult;

int dijkstra_route(const Graph *graph, int source, int destination,
                   RouteMetric metric, RouteResult *result);
int bfs_route(const Graph *graph, int source, int destination, RouteResult *result);
int dfs_reachable(const Graph *graph, int source, unsigned char *visited);
void route_result_free(RouteResult *result);
const char *metric_name(RouteMetric metric);

#endif
