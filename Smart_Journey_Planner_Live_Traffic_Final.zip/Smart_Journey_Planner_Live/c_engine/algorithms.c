#include "algorithms.h"
#include "min_heap.h"
#include <float.h>
#include <stdlib.h>
#include <string.h>

#define INF_WEIGHT (DBL_MAX / 4.0)

typedef struct {
    int *items;
    size_t size;
    size_t capacity;
} IntStack;

static int stack_init(IntStack *stack, size_t capacity) {
    stack->items = (int *)malloc((capacity ? capacity : 8) * sizeof(int));
    stack->size = 0;
    stack->capacity = capacity ? capacity : 8;
    return stack->items != NULL;
}
static int stack_push(IntStack *stack, int value) {
    if (stack->size == stack->capacity) {
        size_t cap = stack->capacity * 2;
        int *grown = (int *)realloc(stack->items, cap * sizeof(int));
        if (!grown) return 0;
        stack->items = grown; stack->capacity = cap;
    }
    stack->items[stack->size++] = value;
    return 1;
}
static int stack_pop(IntStack *stack, int *value) {
    if (!stack || stack->size == 0) return 0;
    *value = stack->items[--stack->size];
    return 1;
}

static double edge_weight(const Edge *edge, RouteMetric metric) {
    switch (metric) {
        case METRIC_DISTANCE: return edge->distance_km;
        case METRIC_TIME: return edge->duration_min;
        case METRIC_FARE: return edge->fare_rupees;
        case METRIC_CONNECTIONS: return 1.0;
        default: return INF_WEIGHT;
    }
}

static int build_result(const Graph *graph, int source, int destination,
                        const int *previous, const Edge *const *previous_edge,
                        double optimized_weight, RouteResult *result) {
    IntStack stack;
    if (!stack_init(&stack, graph->city_count + 1)) return 0;
    int current = destination;
    size_t guard = 0;
    while (current != -1 && guard++ <= graph->city_count) {
        if (!stack_push(&stack, current)) { free(stack.items); return 0; }
        if (current == source) break;
        current = previous[current];
    }
    if (stack.size == 0 || stack.items[stack.size - 1] != source) {
        free(stack.items);
        return 0;
    }
    result->city_ids = (int *)malloc(stack.size * sizeof(int));
    if (!result->city_ids) { free(stack.items); return 0; }
    result->path_length = stack.size;
    result->optimized_weight = optimized_weight;
    result->total_distance_km = 0;
    result->total_duration_min = 0;
    result->total_fare_rupees = 0;
    int city_id;
    size_t out = 0;
    while (stack_pop(&stack, &city_id)) result->city_ids[out++] = city_id;
    free(stack.items);
    for (size_t i = 1; i < result->path_length; ++i) {
        int child = result->city_ids[i];
        const Edge *edge = previous_edge[child];
        if (edge) {
            result->total_distance_km += edge->distance_km;
            result->total_duration_min += edge->duration_min;
            result->total_fare_rupees += edge->fare_rupees;
        }
    }
    result->found = 1;
    return 1;
}

void route_result_free(RouteResult *result) {
    if (!result) return;
    free(result->city_ids);
    memset(result, 0, sizeof(*result));
}

int dijkstra_route(const Graph *graph, int source, int destination,
                   RouteMetric metric, RouteResult *result) {
    if (!graph || !result || source < 0 || destination < 0 ||
        (size_t)source >= graph->city_count || (size_t)destination >= graph->city_count ||
        (metric != METRIC_DISTANCE && metric != METRIC_TIME && metric != METRIC_FARE)) return 0;
    memset(result, 0, sizeof(*result));
    size_t n = graph->city_count;
    double *distance = (double *)malloc(n * sizeof(double));
    int *previous = (int *)malloc(n * sizeof(int));
    unsigned char *visited = (unsigned char *)calloc(n, sizeof(unsigned char));
    const Edge **previous_edge = (const Edge **)calloc(n, sizeof(Edge *));
    MinHeap heap;
    if (!distance || !previous || !visited || !previous_edge || !heap_init(&heap, n + 4)) {
        free(distance); free(previous); free(visited); free(previous_edge);
        return 0;
    }
    for (size_t i = 0; i < n; ++i) { distance[i] = INF_WEIGHT; previous[i] = -1; }
    distance[source] = 0;
    int ok = heap_push(&heap, source, 0);
    HeapNode current;
    while (ok && heap_pop(&heap, &current)) {
        int u = current.vertex;
        if (visited[u] || current.priority != distance[u]) continue;
        visited[u] = 1;
        if (u == destination) break;
        for (Edge *edge = graph->cities[u].head; edge; edge = edge->next) {
            int v = edge->to;
            double weight = edge_weight(edge, metric);
            if (!visited[v] && distance[u] + weight < distance[v]) {
                distance[v] = distance[u] + weight;
                previous[v] = u;
                previous_edge[v] = edge;
                if (!heap_push(&heap, v, distance[v])) { ok = 0; break; }
            }
        }
    }
    if (ok && distance[destination] < INF_WEIGHT)
        ok = build_result(graph, source, destination, previous, previous_edge,
                          distance[destination], result);
    else if (ok) ok = 1; /* No path is a valid, non-error result. */
    heap_free(&heap); free(distance); free(previous); free(visited); free(previous_edge);
    return ok;
}

int bfs_route(const Graph *graph, int source, int destination, RouteResult *result) {
    if (!graph || !result || source < 0 || destination < 0 ||
        (size_t)source >= graph->city_count || (size_t)destination >= graph->city_count) return 0;
    memset(result, 0, sizeof(*result));
    size_t n = graph->city_count;
    int *queue = (int *)malloc(n * sizeof(int));
    int *previous = (int *)malloc(n * sizeof(int));
    const Edge **previous_edge = (const Edge **)calloc(n, sizeof(Edge *));
    unsigned char *visited = (unsigned char *)calloc(n, sizeof(unsigned char));
    if (!queue || !previous || !previous_edge || !visited) {
        free(queue); free(previous); free(previous_edge); free(visited); return 0;
    }
    for (size_t i = 0; i < n; ++i) previous[i] = -1;
    size_t front = 0, rear = 0;
    queue[rear++] = source; visited[source] = 1;
    while (front < rear) {
        int u = queue[front++];
        if (u == destination) break;
        for (Edge *edge = graph->cities[u].head; edge; edge = edge->next) {
            int v = edge->to;
            if (!visited[v]) {
                visited[v] = 1; previous[v] = u; previous_edge[v] = edge;
                queue[rear++] = v;
            }
        }
    }
    int ok = 1;
    if (visited[destination]) {
        ok = build_result(graph, source, destination, previous, previous_edge,
                          (double)(rear ? 0 : 0), result);
        if (ok) result->optimized_weight = (double)(result->path_length - 1);
    }
    free(queue); free(previous); free(previous_edge); free(visited);
    return ok;
}

int dfs_reachable(const Graph *graph, int source, unsigned char *visited) {
    if (!graph || !visited || source < 0 || (size_t)source >= graph->city_count) return 0;
    int *stack = (int *)malloc(graph->city_count * sizeof(int));
    if (!stack) return 0;
    memset(visited, 0, graph->city_count * sizeof(unsigned char));
    size_t top = 0;
    stack[top++] = source; visited[source] = 1;
    while (top > 0) {
        int u = stack[--top];
        for (Edge *edge = graph->cities[u].head; edge; edge = edge->next) {
            if (!visited[edge->to]) { visited[edge->to] = 1; stack[top++] = edge->to; }
        }
    }
    free(stack);
    return 1;
}

const char *metric_name(RouteMetric metric) {
    switch (metric) {
        case METRIC_DISTANCE: return "distance";
        case METRIC_TIME: return "time";
        case METRIC_FARE: return "fare";
        case METRIC_CONNECTIONS: return "connections";
        default: return "unknown";
    }
}
