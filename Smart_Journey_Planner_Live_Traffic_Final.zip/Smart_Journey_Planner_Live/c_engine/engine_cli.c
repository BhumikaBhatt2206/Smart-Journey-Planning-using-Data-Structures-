#include "algorithms.h"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void print_json_string(const char *text) {
    putchar('"');
    for (const unsigned char *p = (const unsigned char *)text; *p; ++p) {
        if (*p == '"' || *p == '\\') { putchar('\\'); putchar(*p); }
        else if (*p < 0x20) printf("\\u%04x", *p);
        else putchar(*p);
    }
    putchar('"');
}

static void print_error_json(const char *message) {
    printf("{\"status\":\"error\",\"message\":");
    print_json_string(message);
    puts("}");
}

static int load_graph_file(const char *path, Graph *graph) {
    FILE *file = fopen(path, "r");
    if (!file) return 0;
    char line[512];
    int line_number = 0, success = 1;
    while (fgets(line, sizeof(line), file)) {
        ++line_number;
        line[strcspn(line, "\r\n")] = '\0';
        if (line[0] == '\0' || line[0] == '#') continue;
        if (strncmp(line, "CITY|", 5) == 0) {
            char name[CITY_NAME_MAX];
            if (sscanf(line + 5, "%99[^|]", name) != 1 || graph_add_city(graph, name) < 0) {
                fprintf(stderr, "Invalid or duplicate city at data line %d.\n", line_number);
                success = 0; break;
            }
        } else if (strncmp(line, "EDGE|", 5) == 0) {
            int from, to;
            double distance, duration, fare;
            char mode[TRANSPORT_MODE_MAX];
            int fields = sscanf(line + 5, "%d|%d|%lf|%lf|%lf|%23[^|\r\n]",
                                &from, &to, &distance, &duration, &fare, mode);
            if (fields != 6 || !graph_add_route(graph, from, to, distance, duration, fare, mode)) {
                fprintf(stderr, "Invalid route at data line %d.\n", line_number);
                success = 0; break;
            }
        } else {
            fprintf(stderr, "Unknown record at data line %d.\n", line_number);
            success = 0; break;
        }
    }
    fclose(file);
    return success && graph->city_count > 0;
}

static RouteMetric parse_metric(const char *name) {
    if (strcmp(name, "distance") == 0) return METRIC_DISTANCE;
    if (strcmp(name, "time") == 0) return METRIC_TIME;
    if (strcmp(name, "fare") == 0) return METRIC_FARE;
    if (strcmp(name, "connections") == 0) return METRIC_CONNECTIONS;
    return 0;
}

static void print_route_json(const Graph *graph, const RouteResult *result,
                             RouteMetric metric, const char *algorithm) {
    if (!result->found) {
        printf("{\"status\":\"not_found\",\"algorithm\":");
        print_json_string(algorithm);
        puts("}");
        return;
    }
    printf("{\"status\":\"ok\",\"algorithm\":"); print_json_string(algorithm);
    printf(",\"metric\":"); print_json_string(metric_name(metric));
    printf(",\"optimized_weight\":%.2f,\"distance_km\":%.2f,\"duration_min\":%.2f,\"fare_rupees\":%.2f,\"connections\":%zu,\"path\":[",
           result->optimized_weight, result->total_distance_km,
           result->total_duration_min, result->total_fare_rupees,
           result->path_length ? result->path_length - 1 : 0);
    for (size_t i = 0; i < result->path_length; ++i) {
        if (i) putchar(',');
        print_json_string(graph->cities[result->city_ids[i]].name);
    }
    puts("]}");
}

static int run_route_command(const Graph *graph, const char *source_name,
                             const char *destination_name, RouteMetric metric,
                             int use_bfs) {
    int source = graph_find_city(graph, source_name);
    int destination = graph_find_city(graph, destination_name);
    if (source < 0 || destination < 0) {
        print_error_json("Unknown source or destination city.");
        return 2;
    }
    RouteResult result = {0};
    int ok = use_bfs ? bfs_route(graph, source, destination, &result)
                     : dijkstra_route(graph, source, destination, metric, &result);
    if (!ok) {
        print_error_json("The route calculation could not be completed (possibly insufficient memory).");
        return 3;
    }
    if (use_bfs) metric = METRIC_CONNECTIONS;
    print_route_json(graph, &result, metric, use_bfs ? "BFS" : "Dijkstra");
    route_result_free(&result);
    return 0;
}

static void build_sample_graph(Graph *graph) {
    const char *names[] = {"Dehradun", "Mussoorie", "Haridwar", "Rishikesh",
                           "Delhi", "Chandigarh", "Shimla", "Meerut"};
    for (size_t i = 0; i < sizeof(names) / sizeof(names[0]); ++i) graph_add_city(graph, names[i]);
    /* Distances preserve the original project. Time and fares are illustrative estimates. */
    graph_add_route(graph, 0, 1, 34, 90, 250, "Road");
    graph_add_route(graph, 0, 2, 52, 95, 300, "Road");
    graph_add_route(graph, 0, 3, 45, 75, 280, "Road");
    graph_add_route(graph, 0, 4, 250, 360, 900, "Road");
    graph_add_route(graph, 0, 5, 170, 300, 750, "Road");
    graph_add_route(graph, 1, 3, 67, 150, 400, "Road");
    graph_add_route(graph, 2, 3, 25, 45, 150, "Road");
    graph_add_route(graph, 2, 7, 150, 210, 650, "Road");
    graph_add_route(graph, 4, 7, 70, 90, 200, "Road");
    graph_add_route(graph, 4, 5, 245, 330, 850, "Road");
    graph_add_route(graph, 5, 6, 115, 180, 600, "Road");
    graph_add_route(graph, 0, 7, 180, 240, 650, "Road");
}

static void interactive_menu(Graph *graph) {
    int choice;
    char source_name[CITY_NAME_MAX], destination_name[CITY_NAME_MAX];
    puts("====================================================");
    puts("       SMART JOURNEY PLANNER - BINARY BRAINS");
    puts("     C Graph Engine | Dijkstra | BFS | DFS | Heap");
    puts("====================================================");
    for (;;) {
        puts("\n1. Shortest-distance route\n2. Fastest estimated route\n3. Cheapest estimated route");
        puts("4. Route with fewest connections (BFS)\n5. Show cities\n6. Show direct connections");
        puts("7. Explore reachable cities (DFS)\n8. Exit");
        printf("Enter choice: ");
        if (scanf("%d", &choice) != 1) {
            int ch; while ((ch = getchar()) != '\n' && ch != EOF) { }
            puts("Invalid input. Enter a number from 1 to 8.");
            continue;
        }
        if (choice >= 1 && choice <= 4) {
            graph_print_cities(graph);
            printf("Source city: ");
            if (scanf(" %99[^\n]", source_name) != 1) { puts("Could not read source."); continue; }
            printf("Destination city: ");
            if (scanf(" %99[^\n]", destination_name) != 1) { puts("Could not read destination."); continue; }
            RouteMetric metric = choice == 1 ? METRIC_DISTANCE : choice == 2 ? METRIC_TIME :
                                 choice == 3 ? METRIC_FARE : METRIC_CONNECTIONS;
            int status = run_route_command(graph, source_name, destination_name, metric, choice == 4);
            (void)status;
        } else if (choice == 5) graph_print_cities(graph);
        else if (choice == 6) graph_print_routes(graph);
        else if (choice == 7) {
            graph_print_cities(graph); printf("Starting city: ");
            if (scanf(" %99[^\n]", source_name) != 1) { puts("Could not read city."); continue; }
            int source = graph_find_city(graph, source_name);
            if (source < 0) { puts("Unknown city."); continue; }
            unsigned char *visited = (unsigned char *)calloc(graph->city_count, 1);
            if (!visited || !dfs_reachable(graph, source, visited)) puts("DFS could not complete.");
            else {
                printf("Cities reachable from %s:\n", graph->cities[source].name);
                for (size_t i = 0; i < graph->city_count; ++i)
                    if (visited[i]) printf("  - %s\n", graph->cities[i].name);
            }
            free(visited);
        } else if (choice == 8) { puts("Thank you for using Smart Journey Planner."); break; }
        else puts("Invalid choice. Select 1 to 8.");
    }
}

int main(int argc, char **argv) {
    Graph graph;
    if (!graph_init(&graph, 8)) { print_error_json("Unable to initialize graph."); return 1; }
    int exit_code = 0;
    if (argc == 1 || (argc == 2 && strcmp(argv[1], "demo") == 0)) {
        build_sample_graph(&graph);
        interactive_menu(&graph);
    } else if (argc >= 3 && strcmp(argv[1], "--data") == 0) {
        if (!load_graph_file(argv[2], &graph)) {
            print_error_json("Could not load graph data. Check the data file format and route values.");
            exit_code = 1;
        } else if (argc == 7 && strcmp(argv[3], "route") == 0) {
            RouteMetric metric = parse_metric(argv[6]);
            if (!metric || metric == METRIC_CONNECTIONS) {
                print_error_json("Metric must be distance, time or fare. Use bfs for fewest connections.");
                exit_code = 2;
            } else exit_code = run_route_command(&graph, argv[4], argv[5], metric, 0);
        } else if (argc == 6 && strcmp(argv[3], "bfs") == 0) {
            exit_code = run_route_command(&graph, argv[4], argv[5], METRIC_CONNECTIONS, 1);
        } else if (argc == 5 && strcmp(argv[3], "dfs") == 0) {
            int source = graph_find_city(&graph, argv[4]);
            if (source < 0) { print_error_json("Unknown starting city."); exit_code = 2; }
            else {
                unsigned char *visited = (unsigned char *)calloc(graph.city_count, 1);
                if (!visited || !dfs_reachable(&graph, source, visited)) {
                    print_error_json("DFS could not complete."); exit_code = 3;
                } else {
                    printf("{\"status\":\"ok\",\"algorithm\":\"DFS\",\"reachable\":[");
                    int first = 1;
                    for (size_t i = 0; i < graph.city_count; ++i) if (visited[i]) {
                        if (!first) putchar(',');
                        first = 0;
                        print_json_string(graph.cities[i].name);
                    }
                    puts("]}");
                }
                free(visited);
            }
        } else {
            print_error_json("Usage: engine --data FILE route SOURCE DESTINATION distance|time|fare | bfs SOURCE DESTINATION | dfs SOURCE");
            exit_code = 2;
        }
    } else {
        print_error_json("Usage: engine [demo] OR engine --data FILE route|bfs|dfs ...");
        exit_code = 2;
    }
    graph_free(&graph);
    return exit_code;
}
