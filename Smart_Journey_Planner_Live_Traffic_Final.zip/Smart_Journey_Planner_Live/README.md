# Smart Journey Planner – Binary Brains

A university PBL journey-planning application that preserves the original C graph/algorithm engine and adds a Flask + SQLite backend, responsive website, GTFS timetable importer, configurable GTFS-Realtime integration and HERE live road-traffic integration.

## Main technologies

- **C:** graph representation, dynamic min-heap, Dijkstra, BFS and DFS for the original road-network planner.
- **Python + Flask:** web backend and JSON APIs.
- **SQLite:** road graph, journey history and imported transit schedule data.
- **HTML/CSS/JavaScript:** interactive dashboard, transit map, provider status and journey search.
- **GTFS / GTFS-Realtime:** standard transit schedule and realtime feed formats.
- **HERE Maps Platform:** traffic-aware car routing, current road-flow speeds, congestion jam factors and incident information (requires your own API key).

## Run on Windows 10/11

1. Install Python 3.10+ and GCC (MinGW-w64/MSYS2 UCRT64).
2. Extract this ZIP into a normal folder.
3. Double-click `run_windows.bat`.
4. On first run, it compiles the C engine, creates `.venv`, installs dependencies and starts Flask.
5. Open `http://127.0.0.1:5000` in Chrome.
6. Keep the terminal window open while using the site. Press Ctrl+C to stop.

The first dependency installation needs internet access. Later runs reuse the virtual environment and compiled C executable.

## Live transit

Open **Live transit centre** in the dashboard. Import an operator's GTFS Schedule ZIP. Configure official HTTPS GTFS-Realtime endpoints in `config/transit_feeds.json` and credentials in `.env` (copy `.env.example`). Each operator's static schedule prefix must match its `id_prefix` in the realtime provider configuration.

The project does not ship with private API keys or claim live transit coverage by default. A live vehicle map, arrival updates and alerts are available only when a transport operator supplies those data feeds. See `docs/LIVE_TRANSIT_SETUP.md` for the Delhi Open Transit Data example and detailed steps.

## Live road traffic

The dashboard also includes a separate **Live road traffic & delay monitor** powered by HERE Routing API v8 and HERE Traffic API v7. It can geocode place names, compare traffic-aware driving route duration with the free-flow baseline when supplied, and retrieve road-flow speeds, jam factors, confidence/source classification, accidents, construction and road-closure incidents for a selected radius.

To activate it, create a HERE Maps Platform API key, copy `.env.example` to `.env` (or edit your existing `.env`) and set `HERE_API_KEY=your_key`. Restart the app, then use the traffic panel. Read `docs/LIVE_TRAFFIC_SETUP.md` for setup, security and usage details. The key is not included in this project. Provider coverage, plan permissions, quotas and possible charges depend on the HERE account.

The traffic panel makes provider requests only when the user presses its buttons; it does not poll the HERE traffic APIs automatically. Transit feed polling is separate. The app never substitutes simulated values when the HERE key is absent or an API request fails.

## Tests

Run `run_tests_windows.bat` after the first setup, or:

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The transit-specific tests can also be run with:

```bat
.venv\Scripts\python.exe -m unittest tests.test_transit -v
```

## Important distinction

The original road graph uses illustrative travel-time and fare estimates. GTFS schedule data is timetable data. GTFS-Realtime data is live only when the configured operator feed is successfully fetched and sufficiently fresh. The app labels these separately.

## Documentation

- `docs/USER_GUIDE.md`
- `docs/DSA_AND_VIVA_GUIDE.md`
- `docs/FINAL_PROJECT_REPORT.md`
- `docs/FINAL_QA_REPORT.md`
- `docs/LIVE_TRANSIT_SETUP.md`
- `docs/LIVE_TRAFFIC_SETUP.md`
