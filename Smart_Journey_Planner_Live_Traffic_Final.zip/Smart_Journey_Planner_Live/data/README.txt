The SQLite database is created automatically on first application launch.
Imported GTFS schedules and journey history are stored locally in journey_planner.db.
Keep this folder and its database file if you want to retain your imported schedules and saved history.
