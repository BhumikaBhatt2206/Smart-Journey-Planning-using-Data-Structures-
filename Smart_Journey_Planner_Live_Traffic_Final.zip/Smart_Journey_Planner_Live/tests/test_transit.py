import io
import tempfile
import unittest
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

from backend.transit import import_gtfs_zip, plan_transit, search_stops, transit_summary, fetch_live, add_transit_transfer, list_transit_transfers


def gtfs_time(value):
    return f'{value//3600:02d}:{(value%3600)//60:02d}:{value%60:02d}'


class TransitIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = Path(self.temp.name) / 'transit.db'
        now = datetime.now()
        start = (now.hour*3600 + now.minute*60 + now.second + 600)
        self.t1_dep = gtfs_time(start)
        self.t1_arr = gtfs_time(start + 600)
        self.t2_dep = gtfs_time(start + 900)
        self.t2_arr = gtfs_time(start + 1500)
        today = now.strftime('%Y%m%d')
        files = {
            'stops.txt': 'stop_id,stop_name,stop_lat,stop_lon\nA,Alpha,30.1,78.1\nB,Bravo,30.2,78.2\nC,Charlie,30.3,78.3\n',
            'routes.txt': 'route_id,agency_id,route_short_name,route_long_name,route_type\nR1,AG,Bus 1,First Bus,3\nR2,AG,Metro 2,Second Metro,1\n',
            'trips.txt': 'route_id,service_id,trip_id,trip_headsign\nR1,SVC,T1,Bravo\nR2,SVC,T2,Charlie\n',
            'stop_times.txt': f'trip_id,arrival_time,departure_time,stop_id,stop_sequence\nT1,{self.t1_dep},{self.t1_dep},A,1\nT1,{self.t1_arr},{self.t1_arr},B,2\nT2,{self.t2_dep},{self.t2_dep},B,1\nT2,{self.t2_arr},{self.t2_arr},C,2\n',
            'calendar.txt': f'service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date\nSVC,1,1,1,1,1,1,1,{today},{today}\n'
        }
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w') as archive:
            for name, content in files.items(): archive.writestr(name, content)
        self.result = import_gtfs_zip(buffer.getvalue(), self.db)

    def tearDown(self): self.temp.cleanup()

    def test_gtfs_import_counts(self):
        self.assertEqual(self.result['stops'], 3)
        self.assertEqual(self.result['trips'], 2)
        self.assertEqual(transit_summary(self.db)['routes'], 2)

    def test_stop_search(self):
        self.assertEqual(search_stops('Alph', self.db)[0]['stop_id'], 'A')

    def test_multileg_itinerary_and_transfer(self):
        result = plan_transit('A', 'C', self.db)
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(len(result['legs']), 2)
        self.assertEqual(result['transfers'], 1)
        self.assertEqual(result['legs'][0]['trip_id'], 'T1')
        self.assertEqual(result['legs'][1]['trip_id'], 'T2')
        self.assertEqual(result['legs'][0]['mode'], 'Bus')
        self.assertEqual(result['legs'][1]['mode'], 'Metro')

    def test_realtime_is_honestly_unconfigured_by_default(self):
        result = fetch_live(self.db)
        self.assertEqual(result['configured'], 0)
        self.assertEqual(result['vehicles'], [])

    def test_merge_operator_with_prefix_avoids_id_collisions(self):
        # Reuse the same feed under another namespace to simulate a second operator.
        import io, zipfile
        from datetime import datetime
        now=datetime.now(); start=now.hour*3600+now.minute*60+now.second+600
        def tm(v): return f'{v//3600:02d}:{(v%3600)//60:02d}:{v%60:02d}'
        today=now.strftime('%Y%m%d')
        data={'stops.txt':'stop_id,stop_name,stop_lat,stop_lon\nA,Alpha,30.1,78.1\nB,Bravo,30.2,78.2\nC,Charlie,30.3,78.3\n','routes.txt':'route_id,agency_id,route_short_name,route_long_name,route_type\nR1,AG,Bus 1,First Bus,3\nR2,AG,Metro 2,Second Metro,1\n','trips.txt':'route_id,service_id,trip_id,trip_headsign\nR1,SVC,T1,Bravo\nR2,SVC,T2,Charlie\n','stop_times.txt':f'trip_id,arrival_time,departure_time,stop_id,stop_sequence\nT1,{tm(start)},{tm(start)},A,1\nT1,{tm(start+600)},{tm(start+600)},B,2\nT2,{tm(start+900)},{tm(start+900)},B,1\nT2,{tm(start+1500)},{tm(start+1500)},C,2\n','calendar.txt':f'service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date\nSVC,1,1,1,1,1,1,1,{today},{today}\n'}
        buff=io.BytesIO()
        with zipfile.ZipFile(buff,'w') as z:
            for name,content in data.items(): z.writestr(name,content)
        import_gtfs_zip(buff.getvalue(),self.db,prefix='metro',merge=True)
        self.assertEqual(transit_summary(self.db)['stops'],6)
        self.assertEqual(search_stops('Alpha',self.db)[0]['stop_id'],'A')
        self.assertTrue(any(x['stop_id']=='metro:A' for x in search_stops('Alpha',self.db,limit=20)))

    def test_interoperator_walking_transfer_connects_bus_and_metro(self):
        from backend.database import database_connection
        with database_connection(self.db) as con:
            con.execute("INSERT INTO transit_stops(stop_id,stop_name,stop_lat,stop_lon) VALUES('B2','Metro Entrance',30.2005,78.2005)")
            con.execute("UPDATE transit_stop_times SET stop_id='B2' WHERE trip_id='T2' AND stop_sequence=1")
            dep_parts=[int(x) for x in self.t2_dep.split(':')]
            arr_parts=[int(x) for x in self.t2_arr.split(':')]
            dep_seconds=dep_parts[0]*3600+dep_parts[1]*60+dep_parts[2]+300
            arr_seconds=arr_parts[0]*3600+arr_parts[1]*60+arr_parts[2]+300
            con.execute("UPDATE transit_stop_times SET departure_time=?,arrival_time=? WHERE trip_id='T2' AND stop_sequence=1",(gtfs_time(dep_seconds),gtfs_time(dep_seconds)))
            con.execute("UPDATE transit_stop_times SET arrival_time=? WHERE trip_id='T2' AND stop_sequence=2",(gtfs_time(arr_seconds),))
        add_transit_transfer('B','B2',5,self.db)
        result=plan_transit('A','C',self.db)
        self.assertEqual(result['status'],'ok')
        self.assertEqual([leg['mode'] for leg in result['legs']],['Bus','Walk','Metro'])
        self.assertEqual(result['transfers'],1)
        self.assertEqual(len(list_transit_transfers(self.db)),2)

    def test_invalid_zip_rejected(self):
        with self.assertRaises(ValueError): import_gtfs_zip(b'not a zip', self.db)


if __name__ == '__main__': unittest.main()
