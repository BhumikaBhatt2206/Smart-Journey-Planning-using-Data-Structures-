"""Integration tests for Flask, SQLite, and the preserved C engine."""
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

try:
    from app import create_app
    FLASK_AVAILABLE = True
except ModuleNotFoundError:
    create_app = None
    FLASK_AVAILABLE = False

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(FLASK_AVAILABLE, "Install requirements.txt to run Flask integration tests")
class BackendIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.TemporaryDirectory()
        cls.engine = Path(cls.temp_dir.name) / ("journey_engine.exe" if os.name == "nt" else "journey_engine")
        compiler = shutil.which("gcc") or shutil.which("cc")
        if not compiler:
            raise unittest.SkipTest("GCC/CC is required to run C integration tests")
        sources = ["engine_cli.c", "graph.c", "algorithms.c", "min_heap.c"]
        command = [compiler, "-std=c11", "-Wall", "-Wextra", "-Wpedantic", "-Werror", "-O2", "-I", str(ROOT / "c_engine")]
        command += [str(ROOT / "c_engine" / name) for name in sources]
        command += ["-o", str(cls.engine)]
        subprocess.run(command, check=True, capture_output=True, text=True)
        os.environ["JOURNEY_ENGINE_PATH"] = str(cls.engine)

    @classmethod
    def tearDownClass(cls):
        os.environ.pop("JOURNEY_ENGINE_PATH", None)
        cls.temp_dir.cleanup()

    def setUp(self):
        self.db_dir = tempfile.TemporaryDirectory()
        self.app = create_app({"TESTING": True, "DATABASE": str(Path(self.db_dir.name) / "test.db")})
        self.client = self.app.test_client()

    def tearDown(self):
        self.db_dir.cleanup()

    def test_health(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["algorithm_engine"], "C")

    def test_seeded_cities_and_routes(self):
        self.assertEqual(len(self.client.get("/api/cities").get_json()["cities"]), 8)
        self.assertEqual(len(self.client.get("/api/routes").get_json()["routes"]), 12)

    def test_dijkstra_distance_uses_c_engine(self):
        response = self.client.get("/api/route?source=Dehradun&destination=Delhi&metric=distance")
        self.assertEqual(response.status_code, 200)
        result = response.get_json()
        self.assertEqual(result["algorithm"], "Dijkstra")
        self.assertEqual(result["path"], ["Dehradun", "Delhi"])
        self.assertAlmostEqual(result["distance_km"], 250)

    def test_dijkstra_time_and_fare(self):
        time_result = self.client.get("/api/route?source=Dehradun&destination=Delhi&metric=time").get_json()
        fare_result = self.client.get("/api/route?source=Dehradun&destination=Delhi&metric=fare").get_json()
        self.assertEqual(time_result["path"], ["Dehradun", "Meerut", "Delhi"])
        self.assertEqual(fare_result["path"], ["Dehradun", "Meerut", "Delhi"])

    def test_bfs_and_dfs(self):
        bfs = self.client.get("/api/bfs?source=Dehradun&destination=Shimla").get_json()
        dfs = self.client.get("/api/dfs?source=Dehradun").get_json()
        self.assertEqual(bfs["algorithm"], "BFS")
        self.assertIn("Shimla", dfs["reachable"])

    def test_add_city_persists_in_sqlite(self):
        response = self.client.post("/api/cities", json={"name": "Jaipur"})
        self.assertEqual(response.status_code, 201)
        self.assertIn("Jaipur", [c["name"] for c in self.client.get("/api/cities").get_json()["cities"]])

    def test_add_route_persists_and_is_used_by_c(self):
        response = self.client.post("/api/routes", json={"source": "Dehradun", "destination": "Mussoorie", "distance_km": 20, "duration_min": 30, "fare_rupees": 100, "transport_mode": "Road"})
        self.assertEqual(response.status_code, 201)
        route = self.client.get("/api/route?source=Dehradun&destination=Mussoorie&metric=distance").get_json()
        self.assertAlmostEqual(route["distance_km"], 20)

    def test_successful_route_is_saved_to_history(self):
        response = self.client.get("/api/route?source=Dehradun&destination=Delhi&metric=distance")
        self.assertEqual(response.status_code, 200)
        history = self.client.get("/api/history").get_json()["history"]
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["path"], ["Dehradun", "Delhi"])

    def test_clear_history_endpoint(self):
        self.client.get("/api/route?source=Dehradun&destination=Delhi&metric=distance")
        response = self.client.delete("/api/history")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.get("/api/history").get_json()["history"], [])

    def test_validation(self):
        self.assertEqual(self.client.get("/api/route?source=A&destination=B&metric=bogus").status_code, 400)
        bad_city = self.client.post("/api/cities", json={"name": ""})
        self.assertEqual(bad_city.status_code, 400)
        bad_route = self.client.post("/api/routes", json={"source": "Dehradun", "destination": "Delhi", "distance_km": -1, "duration_min": 2, "fare_rupees": 3})
        self.assertEqual(bad_route.status_code, 400)


if __name__ == "__main__":
    unittest.main()
