import tempfile
import unittest
from pathlib import Path

from backend.database import initialize_database, list_journey_history, save_journey_history


class JourneyHistoryTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db = Path(self.temp_dir.name) / 'history.db'
        initialize_database(self.db)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_save_and_read_history(self):
        result = {
            'status': 'ok', 'algorithm': 'Dijkstra', 'metric': 'distance',
            'path': ['Dehradun', 'Delhi'], 'distance_km': 250,
            'duration_min': 360, 'fare_rupees': 900,
        }
        saved = save_journey_history('Dehradun', 'Delhi', 'distance', result, self.db)
        self.assertEqual(saved['source'], 'Dehradun')
        history = list_journey_history(self.db)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]['path'], ['Dehradun', 'Delhi'])
        self.assertEqual(history[0]['distance_km'], 250)

    def test_history_is_newest_first_and_limited(self):
        for i in range(3):
            result = {'algorithm': 'Dijkstra', 'path': ['A', 'B'], 'distance_km': i,
                      'duration_min': i, 'fare_rupees': i}
            save_journey_history('A', 'B', 'distance', result, self.db)
        history = list_journey_history(self.db, limit=2)
        self.assertEqual(len(history), 2)
        self.assertEqual(history[0]['distance_km'], 2)


if __name__ == '__main__':
    unittest.main()
