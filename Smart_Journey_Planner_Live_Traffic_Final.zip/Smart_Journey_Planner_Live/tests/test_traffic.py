import os
import unittest
from unittest.mock import patch

from backend import traffic
try:
    from app import create_app
    FLASK_AVAILABLE = True
except ImportError:
    create_app = None
    FLASK_AVAILABLE = False


class TrafficServiceTests(unittest.TestCase):
    def test_route_summary_calculates_delay(self):
        result = traffic._route_summary({"sections": [
            {"summary": {"duration": 900, "baseDuration": 600, "length": 12000}},
            {"summary": {"duration": 300, "baseDuration": 240, "length": 4000}},
        ]})
        self.assertEqual(result["traffic_duration_minutes"], 20)
        self.assertEqual(result["free_flow_duration_minutes"], 14)
        self.assertEqual(result["traffic_delay_minutes"], 6)
        self.assertEqual(result["distance_km"], 16.0)

    @patch.dict(os.environ, {"HERE_API_KEY": "test-key"})
    @patch("backend.traffic._get_json")
    def test_traffic_route_uses_geocoding_and_traffic_route_api(self, mocked):
        mocked.side_effect = [
            {"items": [{"title": "Origin", "position": {"lat": 30.3, "lng": 78.0}}]},
            {"items": [{"title": "Destination", "position": {"lat": 30.4, "lng": 78.1}}]},
            {"routes": [{"sections": [{"summary": {"duration": 1200, "baseDuration": 900, "length": 10000}, "polyline": "encoded"}]}]},
        ]
        result = traffic.traffic_aware_route("Origin", "Destination")
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["routes"][0]["traffic_delay_minutes"], 5)
        self.assertEqual(mocked.call_count, 3)

    @patch.dict(os.environ, {"HERE_API_KEY": "test-key"})
    @patch("backend.traffic._get_json")
    def test_area_returns_flow_speeds_and_incidents(self, mocked):
        mocked.side_effect = [
            {"results": [{"location": {"description": "Main Road", "shape": {"links": []}},
                          "currentFlow": {"speed": 5.0, "freeFlow": 15.0, "jamFactor": 8.2, "confidence": 0.95}}]},
            {"results": [{"incidentDetails": {"type": "accident", "criticality": "major", "description": {"value": "Collision"}},
                          "location": {"description": "Main Road"}}]},
        ]
        result = traffic.traffic_area(30.3, 78.0, 5000)
        self.assertEqual(result["flow_count"], 1)
        self.assertEqual(result["incident_count"], 1)
        self.assertEqual(result["flows"][0]["current_speed_kph"], 18.0)
        self.assertEqual(result["flows"][0]["free_flow_speed_kph"], 54.0)
        self.assertEqual(result["flows"][0]["confidence_source"], "real-time probe data")
        self.assertEqual(result["incidents"][0]["description"], "Collision")

    def test_area_rejects_invalid_coordinates_and_radius(self):
        with self.assertRaises(ValueError):
            traffic.traffic_area(120, 78, 5000, "key")
        with self.assertRaises(ValueError):
            traffic.traffic_area(30, 78, 100, "key")

    def test_missing_key_is_not_reported_as_live(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(traffic.TrafficProviderError):
                traffic.traffic_aware_route("Dehradun", "Delhi")


@unittest.skipUnless(FLASK_AVAILABLE, "Flask is installed by the Windows first-run script")
class TrafficApiTests(unittest.TestCase):
    def setUp(self):
        import tempfile
        from pathlib import Path
        self.temp = tempfile.TemporaryDirectory()
        self.app = create_app({"TESTING": True, "DATABASE": str(Path(self.temp.name) / "test.db")})
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp.cleanup()

    def test_traffic_status_endpoint(self):
        response = self.client.get("/api/traffic/status")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["provider"], "HERE Maps Platform")

    def test_route_requires_string_place_names(self):
        response = self.client.post("/api/traffic/route", json={"origin": 1, "destination": "Delhi"})
        self.assertEqual(response.status_code, 400)

    def test_area_requires_valid_coordinates(self):
        response = self.client.post("/api/traffic/area", json={"latitude": "bad", "longitude": 78})
        self.assertEqual(response.status_code, 400)


if __name__ == "__main__":
    unittest.main()
