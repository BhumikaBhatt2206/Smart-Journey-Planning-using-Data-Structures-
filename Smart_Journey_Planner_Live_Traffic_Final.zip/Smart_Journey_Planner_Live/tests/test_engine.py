import json
import os
import pathlib
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
ENGINE = ROOT / ("journey_engine.exe" if os.name == "nt" else "journey_engine")
DATA = ROOT / "c_engine" / "sample_graph.txt"


def run_engine(*args, data_file=DATA):
    completed = subprocess.run(
        [str(ENGINE), "--data", str(data_file), *args],
        capture_output=True, text=True, check=False
    )
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(
            f"Engine did not return valid JSON. stdout={completed.stdout!r}; stderr={completed.stderr!r}"
        ) from exc
    return completed.returncode, payload


class JourneyEngineTests(unittest.TestCase):
    def test_shortest_distance_preserves_original_result(self):
        code, result = run_engine("route", "Dehradun", "Delhi", "distance")
        self.assertEqual(code, 0)
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["distance_km"], 250.0)
        self.assertEqual(result["path"], ["Dehradun", "Delhi"])

    def test_shortest_distance_to_meerut(self):
        code, result = run_engine("route", "Dehradun", "Meerut", "distance")
        self.assertEqual(code, 0)
        self.assertEqual(result["distance_km"], 180.0)

    def test_fastest_route_metric(self):
        code, result = run_engine("route", "Dehradun", "Delhi", "time")
        self.assertEqual(code, 0)
        self.assertEqual(result["metric"], "time")
        self.assertEqual(result["duration_min"], 330.0)
        self.assertEqual(result["path"], ["Dehradun", "Meerut", "Delhi"])

    def test_cheapest_route_metric(self):
        code, result = run_engine("route", "Dehradun", "Delhi", "fare")
        self.assertEqual(code, 0)
        self.assertEqual(result["metric"], "fare")
        self.assertEqual(result["fare_rupees"], 850.0)
        self.assertEqual(result["path"], ["Dehradun", "Meerut", "Delhi"])

    def test_bfs_fewest_connections(self):
        code, result = run_engine("bfs", "Dehradun", "Shimla")
        self.assertEqual(code, 0)
        self.assertEqual(result["algorithm"], "BFS")
        self.assertEqual(result["connections"], 2)

    def test_dfs_reachability(self):
        code, result = run_engine("dfs", "Dehradun")
        self.assertEqual(code, 0)
        self.assertEqual(result["status"], "ok")
        self.assertEqual(len(result["reachable"]), 8)

    def test_same_city(self):
        code, result = run_engine("route", "Dehradun", "Dehradun", "distance")
        self.assertEqual(code, 0)
        self.assertEqual(result["path"], ["Dehradun"])
        self.assertEqual(result["distance_km"], 0.0)

    def test_unknown_city_is_rejected(self):
        code, result = run_engine("route", "Dehradun", "Atlantis", "distance")
        self.assertNotEqual(code, 0)
        self.assertEqual(result["status"], "error")

    def test_city_lookup_is_case_insensitive(self):
        code, result = run_engine("route", "dehradun", "delhi", "distance")
        self.assertEqual(code, 0)
        self.assertEqual(result["distance_km"], 250.0)

    def test_disconnected_destination_returns_not_found(self):
        with tempfile.TemporaryDirectory() as folder:
            data = pathlib.Path(folder) / "disconnected.txt"
            data.write_text("CITY|A\nCITY|B\nCITY|C\nEDGE|0|1|5|10|20|Road\n", encoding="utf-8")
            code, result = run_engine("route", "A", "C", "distance", data_file=data)
            self.assertEqual(code, 0)
            self.assertEqual(result["status"], "not_found")

    def test_negative_weight_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            data = pathlib.Path(folder) / "negative.txt"
            data.write_text("CITY|A\nCITY|B\nEDGE|0|1|-5|10|20|Road\n", encoding="utf-8")
            code, result = run_engine("route", "A", "B", "distance", data_file=data)
            self.assertNotEqual(code, 0)
            self.assertEqual(result["status"], "error")

    def test_duplicate_city_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            data = pathlib.Path(folder) / "duplicate.txt"
            data.write_text("CITY|A\nCITY|a\n", encoding="utf-8")
            code, result = run_engine("route", "A", "A", "distance", data_file=data)
            self.assertNotEqual(code, 0)
            self.assertEqual(result["status"], "error")

    def test_non_finite_weight_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            data = pathlib.Path(folder) / "not_finite.txt"
            data.write_text("CITY|A\nCITY|B\nEDGE|0|1|nan|10|20|Road\n", encoding="utf-8")
            code, result = run_engine("route", "A", "B", "distance", data_file=data)
            self.assertNotEqual(code, 0)
            self.assertEqual(result["status"], "error")

    def test_duplicate_connection_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            data = pathlib.Path(folder) / "duplicate_route.txt"
            data.write_text(
                "CITY|A\nCITY|B\nEDGE|0|1|5|10|20|Road\nEDGE|0|1|5|10|20|Road\n",
                encoding="utf-8",
            )
            code, result = run_engine("route", "A", "B", "distance", data_file=data)
            self.assertNotEqual(code, 0)
            self.assertEqual(result["status"], "error")


if __name__ == "__main__":
    unittest.main(verbosity=2)
