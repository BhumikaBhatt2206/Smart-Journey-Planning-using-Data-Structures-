"""SQLite persistence and C bridge tests that do not require Flask."""
import os
import tempfile
import unittest
from pathlib import Path

from backend.database import add_city, add_route, initialize_database, list_cities, list_routes
from backend.engine_bridge import run_engine

ROOT = Path(__file__).resolve().parents[1]


class SQLiteDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test.db"
        initialize_database(self.db_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_original_sample_data_is_seeded(self):
        self.assertEqual(len(list_cities(self.db_path)), 8)
        self.assertEqual(len(list_routes(self.db_path)), 12)

    def test_new_city_persists(self):
        add_city("Jaipur", self.db_path)
        self.assertIn("Jaipur", [city["name"] for city in list_cities(self.db_path)])

    def test_new_route_persists(self):
        add_city("Jaipur", self.db_path)
        add_route("Dehradun", "Jaipur", 280, 420, 1000, "Road", self.db_path)
        self.assertEqual(len(list_routes(self.db_path)), 13)

    def test_reverse_identical_route_is_rejected(self):
        add_city("Jaipur", self.db_path)
        add_route("Dehradun", "Jaipur", 280, 420, 1000, "Road", self.db_path)
        with self.assertRaises(ValueError):
            add_route("Jaipur", "Dehradun", 280, 420, 1000, "Road", self.db_path)


class CEngineBridgeTests(unittest.TestCase):
    def test_sqlite_data_is_passed_to_existing_c_engine(self):
        executable = ROOT / ("journey_engine.exe" if os.name == "nt" else "journey_engine")
        if not executable.exists():
            self.skipTest("Build the Stage 3 C engine before running bridge tests")
        previous = os.environ.get("JOURNEY_ENGINE_PATH")
        os.environ["JOURNEY_ENGINE_PATH"] = str(executable)
        try:
            with tempfile.TemporaryDirectory() as td:
                db_path = Path(td) / "bridge.db"
                initialize_database(db_path)
                result = run_engine(db_path, "route", "Dehradun", "Delhi", "distance")
                self.assertEqual(result["algorithm"], "Dijkstra")
                self.assertAlmostEqual(result["distance_km"], 250)
        finally:
            if previous is None:
                os.environ.pop("JOURNEY_ENGINE_PATH", None)
            else:
                os.environ["JOURNEY_ENGINE_PATH"] = previous


if __name__ == "__main__":
    unittest.main()
